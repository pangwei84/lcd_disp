/******************************************************************************
* Copyright (C) 2018, Huada Semiconductor Co.,Ltd All rights reserved.
*
*/
/******************************************************************************/
/** file lcd_code.c
 **
 ** A detailed description is available at
 ** @link Sample Group Some description @endlink
 **
 **   - 2021-01-28  1.0  Devi First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************
* Include files
******************************************************************************/
#include "ddl.h"
#include  <string.h>


/******************************************************************************/
#define		LCD_BASEADDR            M0P_LCD_BASE + 0x40 
//COM6 :SEG38到SEG39没有使用
//COM8 :SEG36到SEG39没有使用
//HDSC MCU LCD模块中SEG和IO  与 段式LCD屏的引脚对应关系图 
//COM 对应关系
//COM0 ========== COM0
//COM1 ========== COM1
//COM2 ========== COM2
//COM3 ========== COM3
//SEG 对应关系
//SEG0 ========== SEG0
//SEG1 ========== SEG1
//SEG2 ========== SEG2
//SEG3 ========== SEG3
//SEG4 ========== SEG4
//SEG5 ========== SEG5
//SEG6 ========== SEG6
//SEG7 ========== SEG7
//LCD RAM regist 
#define LCDSEG0  	*((volatile uint8_t *)(LCD_BASEADDR+0))
#define LCDSEG1  	*((volatile uint8_t *)(LCD_BASEADDR+1))
#define LCDSEG2  	*((volatile uint8_t *)(LCD_BASEADDR+2))
#define LCDSEG3  	*((volatile uint8_t *)(LCD_BASEADDR+3))
#define LCDSEG4  	*((volatile uint8_t *)(LCD_BASEADDR+4))
#define LCDSEG5  	*((volatile uint8_t *)(LCD_BASEADDR+5))
#define LCDSEG6  	*((volatile uint8_t *)(LCD_BASEADDR+6))
#define LCDSEG7  	*((volatile uint8_t *)(LCD_BASEADDR+7))
#define LCDSEG8  	*((volatile uint8_t *)(LCD_BASEADDR+8))
#define LCDSEG9  	*((volatile uint8_t *)(LCD_BASEADDR+9))
#define LCDSEG10  	*((volatile uint8_t *)(LCD_BASEADDR+10))
#define LCDSEG11  	*((volatile uint8_t *)(LCD_BASEADDR+11))
#define LCDSEG12  	*((volatile uint8_t *)(LCD_BASEADDR+12))
#define LCDSEG13  	*((volatile uint8_t *)(LCD_BASEADDR+13))
#define LCDSEG14  	*((volatile uint8_t *)(LCD_BASEADDR+14))
#define LCDSEG15  	*((volatile uint8_t *)(LCD_BASEADDR+15))
#define LCDSEG16  	*((volatile uint8_t *)(LCD_BASEADDR+16))
#define LCDSEG17  	*((volatile uint8_t *)(LCD_BASEADDR+17))
#define LCDSEG18  	*((volatile uint8_t *)(LCD_BASEADDR+18))
#define LCDSEG19  	*((volatile uint8_t *)(LCD_BASEADDR+19))
#define LCDSEG20  	*((volatile uint8_t *)(LCD_BASEADDR+20))
#define LCDSEG21  	*((volatile uint8_t *)(LCD_BASEADDR+21))
#define LCDSEG22  	*((volatile uint8_t *)(LCD_BASEADDR+22))
#define LCDSEG23  	*((volatile uint8_t *)(LCD_BASEADDR+23))
#define LCDSEG24  	*((volatile uint8_t *)(LCD_BASEADDR+24))
#define LCDSEG25  	*((volatile uint8_t *)(LCD_BASEADDR+25))
#define LCDSEG26  	*((volatile uint8_t *)(LCD_BASEADDR+26))
#define LCDSEG27  	*((volatile uint8_t *)(LCD_BASEADDR+27))
#define LCDSEG28  	*((volatile uint8_t *)(LCD_BASEADDR+28))
#define LCDSEG29  	*((volatile uint8_t *)(LCD_BASEADDR+29))
#define LCDSEG30  	*((volatile uint8_t *)(LCD_BASEADDR+30))
#define LCDSEG31  	*((volatile uint8_t *)(LCD_BASEADDR+31))
#define LCDSEG32  	*((volatile uint8_t *)(LCD_BASEADDR+32))
#define LCDSEG33  	*((volatile uint8_t *)(LCD_BASEADDR+36))
#define LCDSEG34  	*((volatile uint8_t *)(LCD_BASEADDR+40))
#define LCDSEG35  	*((volatile uint8_t *)(LCD_BASEADDR+44))
#define LCDSEG36  	*((volatile uint8_t *)(LCD_BASEADDR+48))
#define LCDSEG37  	*((volatile uint8_t *)(LCD_BASEADDR+52))
#define LCDSEG38  	*((volatile uint8_t *)(LCD_BASEADDR+56))
#define LCDSEG39  	*((volatile uint8_t *)(LCD_BASEADDR+60))
#define LCDSEG40  	*((volatile uint8_t *)(LCD_BASEADDR+33))
#define LCDSEG41  	*((volatile uint8_t *)(LCD_BASEADDR+37))
#define LCDSEG42  	*((volatile uint8_t *)(LCD_BASEADDR+41))
#define LCDSEG43  	*((volatile uint8_t *)(LCD_BASEADDR+45))
#define LCDSEG44  	*((volatile uint8_t *)(LCD_BASEADDR+49))
#define LCDSEG45  	*((volatile uint8_t *)(LCD_BASEADDR+53))
#define LCDSEG46  	*((volatile uint8_t *)(LCD_BASEADDR+57))
#define LCDSEG47  	*((volatile uint8_t *)(LCD_BASEADDR+61))
#define LCDSEG48  	*((volatile uint8_t *)(LCD_BASEADDR+34))
#define LCDSEG49  	*((volatile uint8_t *)(LCD_BASEADDR+38))
#define LCDSEG50  	*((volatile uint8_t *)(LCD_BASEADDR+42))
#define LCDSEG51  	*((volatile uint8_t *)(LCD_BASEADDR+46))
//点阵符号宏定义
#define    Fill_1F      LCDSEG0 |= 0x1
#define    Fill_1A      LCDSEG1 |= 0x1
#define    Fill_2F      LCDSEG2 |= 0x1
#define    Fill_2A      LCDSEG3 |= 0x1
#define    Fill_3F      LCDSEG4 |= 0x1
#define    Fill_3A      LCDSEG5 |= 0x1
#define    Fill_4F      LCDSEG6 |= 0x1
#define    Fill_4A      LCDSEG7 |= 0x1
#define    Fill_1G      LCDSEG0 |= 0x2
#define    Fill_1B      LCDSEG1 |= 0x2
#define    Fill_2G      LCDSEG2 |= 0x2
#define    Fill_2B      LCDSEG3 |= 0x2
#define    Fill_3G      LCDSEG4 |= 0x2
#define    Fill_3B      LCDSEG5 |= 0x2
#define    Fill_4G      LCDSEG6 |= 0x2
#define    Fill_4B      LCDSEG7 |= 0x2
#define    Fill_1E      LCDSEG0 |= 0x4
#define    Fill_1C      LCDSEG1 |= 0x4
#define    Fill_2E      LCDSEG2 |= 0x4
#define    Fill_2C      LCDSEG3 |= 0x4
#define    Fill_3E      LCDSEG4 |= 0x4
#define    Fill_3C      LCDSEG5 |= 0x4
#define    Fill_4E      LCDSEG6 |= 0x4
#define    Fill_4C      LCDSEG7 |= 0x4
#define    Fill_P1      LCDSEG0 |= 0x8
#define    Fill_1D      LCDSEG1 |= 0x8
#define    Fill_P2      LCDSEG2 |= 0x8
#define    Fill_2D      LCDSEG3 |= 0x8
#define    Fill_P3      LCDSEG4 |= 0x8
#define    Fill_3D      LCDSEG5 |= 0x8
#define    Fill_P4      LCDSEG6 |= 0x8
#define    Fill_4D      LCDSEG7 |= 0x8
///*============================================*///
///* Function:   	void Initial_LCDDriver(void) 
///* Description:	HDSC LCD 初始化代码	 		 
///*============================================*///
void Initial_LCDDriver(void)
{  
     M0P_SYSCTRL->PERI_CLKEN0_f.GPIO = 1;      //打开GPIO模块时钟
     M0P_SYSCTRL->RCL_CR_f.TRIM = *((volatile uint16_t*)(0x100c20));//LCD模块时钟选择RCL_38.4KHz
      M0P_SYSCTRL->SYSCTRL2 = 0x5A5A;
     M0P_SYSCTRL->SYSCTRL2 = 0xA5A5;
     M0P_SYSCTRL->SYSCTRL0_f.RCL_EN = 1;     //内部低速RCL使能
     M0P_SYSCTRL->PERI_CLKEN0_f.LCD = 1;      //打开LCD模块时钟
     M0P_LCD->CR1  = 0;	
//LCD CR寄存器设置 
     M0P_LCD->CR0_f.DUTY  =3;//LCD Duty 4COM
     M0P_LCD->CR0_f.BSEL  =1;//外部电容 
     M0P_LCD->CR0_f.CONTRAST  =0;//内部电阻驱动对比度调节 
     M0P_LCD->CR0_f.BIAS  =0;//LCD偏置bias设置0:1/3 bias 
     M0P_LCD->CR0_f.CPCLK  =0;//LCD电荷泵时钟频率设置00:2kHz 
     M0P_LCD->CR0_f.LCDCLK  =1;//LCD扫描频率设置01:128Hz 
//LCD IO中COM和SEG设置 
     M0P_GPIO->PAADS_f.PA09 = 1;//COM0 
     M0P_LCD->POEN1_f.C0 = 0;//COM0 
     M0P_GPIO->PAADS_f.PA10 = 1;//COM1 
     M0P_LCD->POEN1_f.C1 = 0;//COM1 
     M0P_GPIO->PAADS_f.PA11 = 1;//COM2 
     M0P_LCD->POEN1_f.C2 = 0;//COM2 
     M0P_GPIO->PAADS_f.PA12 = 1;//COM3 
     M0P_LCD->POEN1_f.C3 = 0;//COM3 
//LCD IO中SEG设置 8SEG
     M0P_GPIO->PAADS_f.PA08 = 1; //SEG0
     M0P_LCD->POEN0_f.S0 = 0; //SEG0
     M0P_GPIO->PCADS_f.PC09 = 1; //SEG1
     M0P_LCD->POEN0_f.S1 = 0; //SEG1
     M0P_GPIO->PCADS_f.PC08 = 1; //SEG2
     M0P_LCD->POEN0_f.S2 = 0; //SEG2
     M0P_GPIO->PCADS_f.PC07 = 1; //SEG3
     M0P_LCD->POEN0_f.S3 = 0; //SEG3
     M0P_GPIO->PCADS_f.PC06 = 1; //SEG4
     M0P_LCD->POEN0_f.S4 = 0; //SEG4
     M0P_GPIO->PBADS_f.PB15 = 1; //SEG5
     M0P_LCD->POEN0_f.S5 = 0; //SEG5
     M0P_GPIO->PBADS_f.PB14 = 1; //SEG6
     M0P_LCD->POEN0_f.S6 = 0; //SEG6
     M0P_GPIO->PBADS_f.PB13 = 1; //SEG7
     M0P_LCD->POEN0_f.S7 = 0; //SEG7
//LCD 外部驱动IO设置 
     M0P_GPIO->PBADS_f.PB03 = 1; //VLCDH 
     M0P_GPIO->PBADS_f.PB04 = 1; //VLCD3 
     M0P_GPIO->PBADS_f.PB05 = 1; //VLCD2 
     M0P_GPIO->PBADS_f.PB06 = 1; //VLCD1 
     M0P_LCD->POEN1_f.S35 = 0; //VLCDH 
     M0P_LCD->POEN1_f.S34 = 0; //VLCD3 
     M0P_LCD->POEN1_f.S33 = 0; //VLCD2 
     M0P_LCD->POEN1_f.S32 = 0; //VLCD1 
     M0P_LCD->POEN1_f.MUX = 0; //MUX 

     M0P_LCD->CR0_f.EN = 1; //LCD 显示使能;
}
/*******************************************************************************
功能描述：  显示全屏和清除显示
*******************************************************************************/
void Disp_Full_Clear(uint8_t temp)
{	
 LCDSEG0  =  temp;
 LCDSEG1  =  temp;
 LCDSEG2  =  temp;
 LCDSEG3  =  temp;
 LCDSEG4  =  temp;
 LCDSEG5  =  temp;
 LCDSEG6  =  temp;
 LCDSEG7  =  temp;
 LCDSEG8  =  temp;
 LCDSEG9  =  temp;
 LCDSEG10  =  temp;
 LCDSEG11  =  temp;
 LCDSEG12  =  temp;
 LCDSEG13  =  temp;
 LCDSEG14  =  temp;
 LCDSEG15  =  temp;
 LCDSEG16  =  temp;
 LCDSEG17  =  temp;
 LCDSEG18  =  temp;
 LCDSEG19  =  temp;
 LCDSEG20  =  temp;
 LCDSEG21  =  temp;
 LCDSEG22  =  temp;
 LCDSEG23  =  temp;
 LCDSEG24  =  temp;
 LCDSEG25  =  temp;
 LCDSEG26  =  temp;
 LCDSEG27  =  temp;
 LCDSEG28  =  temp;
 LCDSEG29  =  temp;
 LCDSEG30  =  temp;
 LCDSEG31  =  temp;
 LCDSEG32  =  temp;
 LCDSEG33  =  temp;
 LCDSEG34  =  temp;
 LCDSEG35  =  temp;
 LCDSEG36  =  temp;
 LCDSEG37  =  temp;
 LCDSEG38  =  temp;
 LCDSEG39  =  temp;
 LCDSEG40  =  temp;
 LCDSEG41  =  temp;
 LCDSEG42  =  temp;
 LCDSEG43  =  temp;
 LCDSEG44  =  temp;
 LCDSEG45  =  temp;
 LCDSEG46  =  temp;
 LCDSEG47  =  temp;
 LCDSEG48  =  temp;
 LCDSEG49  =  temp;
 LCDSEG50  =  temp;
 LCDSEG51  =  temp;
}
//===============================================
//数字显示函数
//===============================================
void LCD_Digit_1(uint8_t V_Data)
{	
  if(V_Data>9)  return; 
  if(V_Data == 0 ) // 显示数字
  { Fill_1A;   Fill_1B;   Fill_1C;   Fill_1D;   Fill_1E;   Fill_1F;  }
  else if(V_Data == 1 ) // 显示数字
  { Fill_1B;   Fill_1C;  }
  else if(V_Data == 2 ) // 显示数字
  { Fill_1A;   Fill_1B;   Fill_1G;   Fill_1D;   Fill_1E;  }
  else if(V_Data == 3 ) // 显示数字
  { Fill_1A;   Fill_1B;   Fill_1G;   Fill_1D;   Fill_1C;  }
  else if(V_Data == 4 ) // 显示数字
  { Fill_1F;   Fill_1B;   Fill_1G;   Fill_1C;  }
  else if(V_Data == 5 ) // 显示数字
  { Fill_1A;   Fill_1F;   Fill_1G;   Fill_1D;   Fill_1C;  }
  else if(V_Data == 6 ) // 显示数字
  { Fill_1A;   Fill_1E;   Fill_1G;   Fill_1D;   Fill_1C;   Fill_1F;  }
  else if(V_Data == 7 ) // 显示数字
  { Fill_1A;   Fill_1B;   Fill_1C;  }
  else if(V_Data == 8 ) // 显示数字
  { Fill_1A;   Fill_1E;   Fill_1G;   Fill_1D;   Fill_1C;   Fill_1F;   Fill_1B;  }
  else if(V_Data == 9 ) // 显示数字
  { Fill_1A;   Fill_1G;   Fill_1B;   Fill_1C;   Fill_1F;  }
}
void LCD_Digit_2(uint8_t V_Data)
{	
  if(V_Data>9)  return; 
  if(V_Data == 0 ) // 显示数字
  { Fill_2A;   Fill_2B;   Fill_2C;   Fill_2D;   Fill_2E;   Fill_2F;  }
  else if(V_Data == 1 ) // 显示数字
  { Fill_2B;   Fill_2C;  }
  else if(V_Data == 2 ) // 显示数字
  { Fill_2A;   Fill_2B;   Fill_2G;   Fill_2D;   Fill_2E;  }
  else if(V_Data == 3 ) // 显示数字
  { Fill_2A;   Fill_2B;   Fill_2G;   Fill_2D;   Fill_2C;  }
  else if(V_Data == 4 ) // 显示数字
  { Fill_2F;   Fill_2B;   Fill_2G;   Fill_2C;  }
  else if(V_Data == 5 ) // 显示数字
  { Fill_2A;   Fill_2F;   Fill_2G;   Fill_2D;   Fill_2C;  }
  else if(V_Data == 6 ) // 显示数字
  { Fill_2A;   Fill_2E;   Fill_2G;   Fill_2D;   Fill_2C;   Fill_2F;  }
  else if(V_Data == 7 ) // 显示数字
  { Fill_2A;   Fill_2B;   Fill_2C;  }
  else if(V_Data == 8 ) // 显示数字
  { Fill_2A;   Fill_2E;   Fill_2G;   Fill_2D;   Fill_2C;   Fill_2F;   Fill_2B;  }
  else if(V_Data == 9 ) // 显示数字
  { Fill_2A;   Fill_2G;   Fill_2B;   Fill_2C;   Fill_2F;  }
}
void LCD_Digit_3(uint8_t V_Data)
{	
  if(V_Data>9)  return; 
  if(V_Data == 0 ) // 显示数字
  { Fill_3A;   Fill_3B;   Fill_3C;   Fill_3D;   Fill_3E;   Fill_3F;  }
  else if(V_Data == 1 ) // 显示数字
  { Fill_3B;   Fill_3C;  }
  else if(V_Data == 2 ) // 显示数字
  { Fill_3A;   Fill_3B;   Fill_3G;   Fill_3D;   Fill_3E;  }
  else if(V_Data == 3 ) // 显示数字
  { Fill_3A;   Fill_3B;   Fill_3G;   Fill_3D;   Fill_3C;  }
  else if(V_Data == 4 ) // 显示数字
  { Fill_3F;   Fill_3B;   Fill_3G;   Fill_3C;  }
  else if(V_Data == 5 ) // 显示数字
  { Fill_3A;   Fill_3F;   Fill_3G;   Fill_3D;   Fill_3C;  }
  else if(V_Data == 6 ) // 显示数字
  { Fill_3A;   Fill_3E;   Fill_3G;   Fill_3D;   Fill_3C;   Fill_3F;  }
  else if(V_Data == 7 ) // 显示数字
  { Fill_3A;   Fill_3B;   Fill_3C;  }
  else if(V_Data == 8 ) // 显示数字
  { Fill_3A;   Fill_3E;   Fill_3G;   Fill_3D;   Fill_3C;   Fill_3F;   Fill_3B;  }
  else if(V_Data == 9 ) // 显示数字
  { Fill_3A;   Fill_3G;   Fill_3B;   Fill_3C;   Fill_3F;  }
}
void LCD_Digit_4(uint8_t V_Data)
{	
  if(V_Data>9)  return; 
  if(V_Data == 0 ) // 显示数字
  { Fill_4A;   Fill_4B;   Fill_4C;   Fill_4D;   Fill_4E;   Fill_4F;  }
  else if(V_Data == 1 ) // 显示数字
  { Fill_4B;   Fill_4C;  }
  else if(V_Data == 2 ) // 显示数字
  { Fill_4A;   Fill_4B;   Fill_4G;   Fill_4D;   Fill_4E;  }
  else if(V_Data == 3 ) // 显示数字
  { Fill_4A;   Fill_4B;   Fill_4G;   Fill_4D;   Fill_4C;  }
  else if(V_Data == 4 ) // 显示数字
  { Fill_4F;   Fill_4B;   Fill_4G;   Fill_4C;  }
  else if(V_Data == 5 ) // 显示数字
  { Fill_4A;   Fill_4F;   Fill_4G;   Fill_4D;   Fill_4C;  }
  else if(V_Data == 6 ) // 显示数字
  { Fill_4A;   Fill_4E;   Fill_4G;   Fill_4D;   Fill_4C;   Fill_4F;  }
  else if(V_Data == 7 ) // 显示数字
  { Fill_4A;   Fill_4B;   Fill_4C;  }
  else if(V_Data == 8 ) // 显示数字
  { Fill_4A;   Fill_4E;   Fill_4G;   Fill_4D;   Fill_4C;   Fill_4F;   Fill_4B;  }
  else if(V_Data == 9 ) // 显示数字
  { Fill_4A;   Fill_4G;   Fill_4B;   Fill_4C;   Fill_4F;  }
}

void Disp_OneDigit(uint8_t  V_DataNum,uint8_t  V_Data)
{ 
 if( V_DataNum == 1)   LCD_Digit_1( V_Data );
 if( V_DataNum == 2)   LCD_Digit_2( V_Data );
 if( V_DataNum == 3)   LCD_Digit_3( V_Data );
 if( V_DataNum == 4)   LCD_Digit_4( V_Data ); 
} 
///***********************************************************************************///
///*Function：Disp_DigitS	                          		                         
///*Description：底层数字转换           					 						 
///***********************************************************************************///
void Disp_DigitS(uint8_t  *P_Data,uint8_t   V_StartNum,uint8_t   V_Num)
{
 uint8_t   V_CircleNum;
 for(V_CircleNum=V_StartNum; V_CircleNum<V_Num; V_CircleNum++)  
 { 
   Disp_OneDigit(V_CircleNum,P_Data[V_CircleNum] );	
 } 
}

///***********************************************************************************///
///*Function：Test_Display  LCD 显示测试程序
///***********************************************************************************///
void Test_Display(void)
{
   uint8_t i,j,buff[ 5 ];
   Initial_LCDDriver();
   memset(buff,0, 5 );
   Disp_Full_Clear(0xFF); //全显示
   for(i = 1; i < 5; i++)//显示每一个数字
   {
     for(j = 0; j < 10; j++)
     {
      delay1ms(500);
      Disp_Full_Clear(0x00); //全清除
      Disp_OneDigit(i, j);	
     }
   }
    Disp_Full_Clear(0x00); //全清除
   memset(buff,0, 5 );
   for(i = 0; i < 10; i++)//显示所有的数字
   {
    for(j = 0; j < 5;j++)
    {
     buff[j] = i;
    }
    Disp_DigitS(buff,1, 5 );	
    delay1ms(500);
    Disp_Full_Clear(0x00); //全清除
   }
 //LCD 中宏定义显示 
    Disp_Full_Clear(0x00); //全清除
    delay1ms(500);
    Fill_P1;
    delay1ms(500);
    Fill_P2;
    delay1ms(500);
    Fill_P3;
    delay1ms(500);
    Fill_P4;
   while(1);
}
