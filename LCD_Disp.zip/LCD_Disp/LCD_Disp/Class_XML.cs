﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml; 

namespace LCD_Disp
{
    class Class_XML
    {
        public Class_XML()
        { }


        public String CreateXmlFile(XmlDocument xmlDoc, String path,String[] name, String[] value, int len , int flag)
        {
            try
            { 
                //创建类型声明节点  
                XmlNode node = xmlDoc.CreateXmlDeclaration("1.0", "utf-8", "");
                if (flag == 0)
                {
                    xmlDoc.AppendChild(node);
                }
                //创建根节点  
                XmlNode root = xmlDoc.CreateElement("Config");
                xmlDoc.AppendChild(root);
                for (int i = 0; i < len; i++)
                {
                    CreateNode(xmlDoc, root, name[i], value[i]);
                }
                xmlDoc.Save(path);

                return null;
            }
            catch (Exception e)
            {
                //显示错误信息  
                return (e.Message);
            } 
        }
        private void CreateNode(XmlDocument xmlDoc, XmlNode parentNode, string name, string value)
        {
            XmlNode node = xmlDoc.CreateNode(XmlNodeType.Element, name, null);
            node.InnerText = value;
            parentNode.AppendChild(node);
        }

        public String ReadXmlFileNode(XmlDocument xmlDoc, String path, String name)
        {
            try
            {
                String str1 = "";
                //加载XML文件
                xmlDoc.Load(path);
                XmlNodeList list = xmlDoc.SelectNodes("/Config/" + name);

                foreach (XmlNode item in list)
                {
                    str1 = item.OuterXml;  //获取全部的标记
                    str1 = item.InnerText;  //获取标记里面的值
                }
                return str1;
            }

            catch (Exception e)
            {
                //显示错误信息  
                return (e.Message);
            }
        }

        public String DeletXmlFileNode(XmlDocument xmlDoc, String path, String node)
        {
            try
            {
                //加载XML文件
                xmlDoc.Load(path);
                XmlNode list = xmlDoc.SelectSingleNode(node);
                //移除。
                list.RemoveAll();
                return null;
            }

            catch (Exception e)
            {
                //显示错误信息  
                return (e.Message);
            }
        }


    }
}
