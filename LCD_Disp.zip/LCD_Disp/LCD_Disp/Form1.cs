﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Web;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Xml;

namespace LCD_Disp
{
    public partial class Form1 : Form
    {
        Class_XML xml_operate = new Class_XML();
        XmlDocument xmlDoc = new XmlDocument();
        const int Max_Save_Num = 20;
        String[] save_name = new String[Max_Save_Num];
        String[] save_value = new String[Max_Save_Num];

        //  定义下拉列表框
        private ComboBox cmb_Temp = new ComboBox();
        private ComboBox cmb_Seg = new ComboBox();
        DataTable dt = new DataTable();
        const int MAX_LCD_Seg = 52;
        const int MAX_LCD_Com = 8;
        //fixed String COM_Map[MAX_LCD_Com];
        //fixed String SEG_Map[MAX_LCD_Seg];
        int Current_COM;
        int Current_SEG;
        int Disp_Flag = 0;
        int LCD_Type = 0;   //LCD 驱动类型
        //字符对应的数字和表达式
        String[] Sys_Num = new String[MAX_LCD_Seg*8];
        int Sys_Count = 0;

        //驱动方式设置说明
        String str_inr = "由于内部电阻驱动方式，无需外部电路支持。VLCDH、VLCD3、VLCD2、VLCD1四个IO管脚用于GPIO或者其他复用功能。\r\n" +
"当选择内部电阻分压时，芯片会自动切换到内部的电路，这种模式驱动能力较弱。\r\n" +
"当选择 1/2bias 时，大功耗/中功耗/小功耗电阻分别为 240K/360K/720K,\r\n" +
"当选择1/3bias 时，大功耗/中功耗/小功耗电阻分别为 360K/540K/1080K。 \r\n" +
"通过内部LCD_CR0中的Contrast 调整电压使得VLCD电压 = LCD 玻璃电压 \r\n";
        String str_exr = "由于外部电阻驱动方式，需要外部电路支持，而且额外占用MCU上的VLCDH、VLCD3、VLCD2、VLCD1四个IO管脚，用于外部分压。\r\n" +
"Rx 调整保证VLCD3 = VLCD 电压。VLCDH = VDD电压其余电阻R保持阻值相等。\r\n";
        String str_exc = "由于外部电容驱动方式，需要外部电路支持，而且额外占用MCU上的VLCDH、VLCD3、VLCD2、VLCD1四个IO管脚，用于电容分压。\r\n" +
"LCD屏电压 = VDD电压(VLCDH)，驱动能力强，功耗最低0.5uA。其中电容推荐均为0.1uF。\r\n";




        public Form1()
        {
            InitializeComponent();
            Init_Form();
            cmb_Temp.Visible = false;
            Current_COM = 4;
            BindCom();



            //  添加下拉列表框事件
            cmb_Temp.SelectedIndexChanged += new EventHandler(cmb_Temp_SelectedIndexChanged);
            //  将下拉列表框加入到DataGridView控件中
            this.dataGridView.Controls.Add(cmb_Temp);
            //  添加下拉列表框事件
            cmb_Seg.SelectedIndexChanged += new EventHandler(cmb_Seg_SelectedIndexChanged);
            //  将下拉列表框加入到DataGridView控件中
            this.dataGridView.Controls.Add(cmb_Seg);



            cmb_Seg.Visible = false;
            BindSeg();

            Disp_Flag = 0;
            Select_Pic();
            //test
            button2.Visible = false;
            button1.Visible = false;
        }


        [DllImport("kernel32.dll")]
        static extern uint GetTickCount();
        public static void Delay(int ms)
        {
            uint start = GetTickCount();
            while (GetTickCount() - start < ms)
            {
                System.Windows.Forms.Application.DoEvents();
            }
        }

        public void Init_Form()
        {
            String str1;

            comboBox_LCDCLK.Items.Add("RCL_32.7KHz");
            comboBox_LCDCLK.Items.Add("RCL_38.4KHz");
            comboBox_LCDCLK.SelectedIndex = 0;

            comboBox_LCD_COM.Items.Add("1COM");
            comboBox_LCD_COM.Items.Add("2COM");
            comboBox_LCD_COM.Items.Add("3COM");
            comboBox_LCD_COM.Items.Add("4COM");
            comboBox_LCD_COM.Items.Add("6COM");
            comboBox_LCD_COM.Items.Add("8COM");

            for (int i = 0; i < MAX_LCD_Seg + 1 ; i++)// 初始化LCD 的SEG
            {
                str1 =  i.ToString() + "SEG";
                comboBox_LCD_SEG.Items.Add(str1);
            }
            comboBox_LCD_SEG.SelectedIndex = 6;            
            comboBox_LCD_COM.SelectedIndex = 3;

            //默认8字配置
            radioButton_8Digit.Checked = true;
            radioButton_miDigit.Checked = false;
            Config_8orMiDigit(false,7);

            comboBox_LCDType.SelectedIndex = 1;
            richTextBox_LCDType.Text = str_exc; //默认外部电容方式
            LCD_Type = 1;
            comboBox_LCDConstrast.SelectedIndex = 0;
            comboBox_LCDBias.SelectedIndex = 0;
            comboBox_LCDCpClk.SelectedIndex = 0;
            comboBox_LCDLCK.SelectedIndex = 0;

            textBox_Num.Text = "0";

            Get_Config_Name(); //Config XML 固定配置项目
        }

        public void Config_8orMiDigit(bool temp, int num )
        {
                comboBox_Num_1.Items.Clear();
                comboBox_Num_2.Items.Clear();
                comboBox_Num_3.Items.Clear();
                comboBox_Num_4.Items.Clear();
                comboBox_Num_5.Items.Clear();
                comboBox_Num_6.Items.Clear();
                comboBox_Num_7.Items.Clear();
                comboBox_Num_8.Items.Clear();
                comboBox_Num_9.Items.Clear();
                comboBox_Num_10.Items.Clear();
                comboBox_Num_11.Items.Clear();
                comboBox_Num_12.Items.Clear();
                comboBox_Num_13.Items.Clear();
                comboBox_Num_14.Items.Clear();
                comboBox_Num_15.Items.Clear();
                comboBox_Num_16.Items.Clear();
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_1.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_2.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_3.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_4.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_5.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_6.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_7.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_8.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_9.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_10.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_11.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_12.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_13.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_14.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_15.Items.Add((char)('A' + i));
                }
                for (int i = 0; i < num; i++)
                {
                    comboBox_Num_16.Items.Add((char)('A' + i));
                }
                comboBox_Num_8.Visible = temp;
                comboBox_Num_9.Visible = temp;
                comboBox_Num_10.Visible = temp;
                comboBox_Num_11.Visible = temp;
                comboBox_Num_12.Visible = temp;
                comboBox_Num_13.Visible = temp;
                comboBox_Num_14.Visible = temp;
                comboBox_Num_15.Visible = temp;
                comboBox_Num_16.Visible = temp;
                label22.Visible = temp;
                label23.Visible = temp;
                label24.Visible = temp;
                label25.Visible = temp;
                label26.Visible = temp;
                label27.Visible = temp;
                label28.Visible = temp;
                label29.Visible = temp;
                label30.Visible = temp;
            if (radioButton_8Digit.Checked == true)
            {
                groupBox1.Text = "8字配置";
                pictureBox2.Image = LCD_Disp.Properties.Resources._8字;
            }
            else if (radioButton_miDigit.Checked == true)
            {
                groupBox1.Text = "米字16配置";
                pictureBox2.Image = LCD_Disp.Properties.Resources.MI字;

                comboBox_Num_8.SelectedIndex = 7;
                comboBox_Num_9.SelectedIndex = 8;
                comboBox_Num_10.SelectedIndex = 9;
                comboBox_Num_11.SelectedIndex = 10;
                comboBox_Num_12.SelectedIndex = 11;
                comboBox_Num_13.SelectedIndex = 12;
                comboBox_Num_14.SelectedIndex = 13;
                comboBox_Num_15.SelectedIndex = 14;
                comboBox_Num_16.SelectedIndex = 15;
            }
            else
            {
                groupBox1.Text = "米字14配置";
                pictureBox2.Image = LCD_Disp.Properties.Resources.MI_14;

                comboBox_Num_8.SelectedIndex = 7;
                comboBox_Num_9.SelectedIndex = 8;
                comboBox_Num_10.SelectedIndex = 9;
                comboBox_Num_11.SelectedIndex = 10;
                comboBox_Num_12.SelectedIndex = 11;
                comboBox_Num_13.SelectedIndex = 12;
                comboBox_Num_14.SelectedIndex = 13;
                label22.Visible = false;
                label30.Visible = false;
                comboBox_Num_15.Visible = false;
                comboBox_Num_16.Visible = false;
            }
            comboBox_Num_1.SelectedIndex = 0;
            comboBox_Num_2.SelectedIndex = 1;
            comboBox_Num_3.SelectedIndex = 2;
            comboBox_Num_4.SelectedIndex = 3;
            comboBox_Num_5.SelectedIndex = 4;
            comboBox_Num_6.SelectedIndex = 5;
            comboBox_Num_7.SelectedIndex = 6;
        }

        ///   <summary>
        ///  绑定COM下拉列表框
        ///   </summary>
        private void BindCom()
        {
            DataTable dtSex = new DataTable();
            dtSex.Columns.Add(" Value ");
            dtSex.Columns.Add(" Name ");
            DataRow drSex;

            for (int i = 0; i < Current_COM; i++)
            {   
                drSex = dtSex.NewRow();
                drSex[0] =  i.ToString();
                drSex[1] = "COM" + i.ToString();
                dtSex.Rows.Add(drSex);
            }
            cmb_Temp.ValueMember = " Value ";
            cmb_Temp.DisplayMember = " Name ";
            cmb_Temp.DataSource = dtSex;
            cmb_Temp.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        ///   <summary>
        ///  绑定SEG下拉列表框
        ///   </summary>
        private void BindSeg()
        {
            DataTable dtSex = new DataTable();
            dtSex.Columns.Add(" Value ");
            dtSex.Columns.Add(" Name ");
            DataRow drSex;

            for (int i = 0; i < MAX_LCD_Seg; i++)
            {
                drSex = dtSex.NewRow();
                drSex[0] = i.ToString();
                drSex[1] = "SEG" + i.ToString();
                dtSex.Rows.Add(drSex);
            }
            cmb_Seg.ValueMember = " Value ";
            cmb_Seg.DisplayMember = " Name ";
            cmb_Seg.DataSource = dtSex;
            cmb_Seg.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        private void cmb_Temp_SelectedIndexChanged(object sender, EventArgs e)
        {
            string str1 = ((ComboBox)sender).Text;
           dataGridView.CurrentCell.Value = str1;
           dataGridView.CurrentCell.Tag = str1.Substring(3,1);
           dataGridView.Rows[0].Cells[0].Value = "COM_SEG";
        }
        private void cmb_Seg_SelectedIndexChanged(object sender, EventArgs e)
        {
            string str1 = ((ComboBox)sender).Text;
            dataGridView.CurrentCell.Value = str1;

            dataGridView.CurrentCell.Tag = str1.Substring(3, str1.Length - 3);
            dataGridView.Rows[0].Cells[0].Value = "COM_SEG";
        }
        //当用户选择的单元格移动到性别这一列时，我们要显示下拉列表框，添加如下事件
        private void dataGridView_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                //COM
                if (this.dataGridView.CurrentCell.ColumnIndex == 0)
                {
                    Rectangle rect = dataGridView.GetCellDisplayRectangle(dataGridView.CurrentCell.ColumnIndex, dataGridView.CurrentCell.RowIndex, false);
                    cmb_Temp.Left = rect.Left;
                    cmb_Temp.Top = rect.Top;
                    cmb_Temp.Width = rect.Width;
                    cmb_Temp.Height = rect.Height;
                    cmb_Temp.Visible = true;
                }
                else
                {
                    cmb_Temp.Visible = false;
                    string str1 = dataGridView.Rows[2].Cells[0].Value.ToString();  //test
                }
                //SEG
                if (this.dataGridView.CurrentCell.RowIndex == 0)
                {
                    Rectangle rect = dataGridView.GetCellDisplayRectangle(dataGridView.CurrentCell.ColumnIndex, dataGridView.CurrentCell.RowIndex, false);
                    cmb_Seg.Left = rect.Left;
                    cmb_Seg.Top = rect.Top;
                    cmb_Seg.Width = rect.Width;
                    cmb_Seg.Height = rect.Height;
                    cmb_Seg.Visible = true;
                }
                else
                {
                    cmb_Seg.Visible = false;
                    string str1 = dataGridView.Rows[2].Cells[0].Value.ToString();  //test
                }

            }
            catch
            { 
            
            }
        }

        public static DataTable OpenCSV(string filePath)//从csv读取数据返回table
        {
            System.Text.Encoding encoding = GetType(filePath); //Encoding.ASCII;//
            DataTable dt1 = new DataTable();
            System.IO.FileStream fs = new System.IO.FileStream(filePath, System.IO.FileMode.Open,
                System.IO.FileAccess.Read);

            System.IO.StreamReader sr = new System.IO.StreamReader(fs, encoding);

            //记录每次读取的一行记录
            string strLine = "";
            //记录每行记录中的各字段内容
            string[] aryLine = null;
            string[] tableHead = null;
            //标示列数
            int columnCount = 0;
            //标示是否是读取的第一行
            bool IsFirst = true;
            //逐行读取CSV中的数据
            while ((strLine = sr.ReadLine()) != null)
            {
                if (IsFirst == true)
                {
                    tableHead = strLine.Split(',');
                    IsFirst = false;
                    columnCount = tableHead.Length;
                    //创建列
                    for (int i = 0; i < columnCount; i++)
                    {
                        DataColumn dc = new DataColumn(tableHead[i]);
                        dt1.Columns.Add(dc);
                    }
                }
                else
                {
                    aryLine = strLine.Split(',');
                    DataRow dr = dt1.NewRow();
                    for (int j = 0; j < columnCount; j++)
                    {
                        dr[j] = aryLine[j];
                    }
                    dt1.Rows.Add(dr);
                }
            }
            if (aryLine != null && aryLine.Length > 0)
            {
                dt1.DefaultView.Sort = tableHead[0] + " " + "asc";
            }

            sr.Close();
            fs.Close();
            return dt1;
        }
        /// 给定文件的路径，读取文件的二进制数据，判断文件的编码类型
        /// <param name="FILE_NAME">文件路径</param>
        /// <returns>文件的编码类型</returns>

        public static System.Text.Encoding GetType(string FILE_NAME)
        {
            System.IO.FileStream fs = new System.IO.FileStream(FILE_NAME, System.IO.FileMode.Open,
                System.IO.FileAccess.Read);
            System.Text.Encoding r = GetType(fs);
            fs.Close();
            return r;
        }

        /// 通过给定的文件流，判断文件的编码类型
        /// <param name="fs">文件流</param>
        /// <returns>文件的编码类型</returns>
        public static System.Text.Encoding GetType(System.IO.FileStream fs)
        {
            byte[] Unicode = new byte[] { 0xFF, 0xFE, 0x41 };
            byte[] UnicodeBIG = new byte[] { 0xFE, 0xFF, 0x00 };
            byte[] UTF8 = new byte[] { 0xEF, 0xBB, 0xBF }; //带BOM
            System.Text.Encoding reVal = System.Text.Encoding.Default;

            System.IO.BinaryReader r = new System.IO.BinaryReader(fs, System.Text.Encoding.Default);
            int i;
            int.TryParse(fs.Length.ToString(), out i);
            byte[] ss = r.ReadBytes(i);
            if (IsUTF8Bytes(ss) || (ss[0] == 0xEF && ss[1] == 0xBB && ss[2] == 0xBF))
            {
                reVal = System.Text.Encoding.UTF8;
            }
            else if (ss[0] == 0xFE && ss[1] == 0xFF && ss[2] == 0x00)
            {
                reVal = System.Text.Encoding.BigEndianUnicode;
            }
            else if (ss[0] == 0xFF && ss[1] == 0xFE && ss[2] == 0x41)
            {
                reVal = System.Text.Encoding.Unicode;
            }
            r.Close();
            return reVal;
        }

        /// 判断是否是不带 BOM 的 UTF8 格式
        /// <param name="data"></param>
        /// <returns></returns>
        private static bool IsUTF8Bytes(byte[] data)
        {
            int charByteCounter = 1;　 //计算当前正分析的字符应还有的字节数
            byte curByte; //当前分析的字节.
            for (int i = 0; i < data.Length; i++)
            {
                curByte = data[i];
                if (charByteCounter == 1)
                {
                    if (curByte >= 0x80)
                    {
                        //判断当前
                        while (((curByte <<= 1) & 0x80) != 0)
                        {
                            charByteCounter++;
                        }
                        //标记位首位若为非0 则至少以2个1开始 如:110XXXXX...........1111110X　
                        if (charByteCounter == 1 || charByteCounter > 6)
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    //若是UTF-8 此时第一位必须为1
                    if ((curByte & 0xC0) != 0x80)
                    {
                        return false;
                    }
                    charByteCounter--;
                }
            }
            if (charByteCounter > 1)
            {
                throw new Exception("非预期的byte格式");
            }
            return true;
        }
        public static void SaveCSV(DataTable dt, string fullPath)//table数据写入csv
        {
            System.IO.FileInfo fi = new System.IO.FileInfo(fullPath);
            if (!fi.Directory.Exists)
            {
                fi.Directory.Create();
            }
            System.IO.FileStream fs = new System.IO.FileStream(fullPath, System.IO.FileMode.Create,
                System.IO.FileAccess.Write);
            System.IO.StreamWriter sw = new System.IO.StreamWriter(fs, System.Text.Encoding.UTF8);
            string data = "";

            for (int i = 0; i < dt.Columns.Count; i++)//写入列名
            {
                data += dt.Columns[i].ColumnName.ToString();
                if (i < dt.Columns.Count - 1)
                {
                    data += ",";
                }
            }
            sw.WriteLine(data);

            for (int i = 0; i < dt.Rows.Count; i++) //写入各行数据
            {
                data = "";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    string str = dt.Rows[i][j].ToString();
                    str = str.Replace("\"", "\"\"");//替换英文冒号 英文冒号需要换成两个冒号
                    if (str.Contains(',') || str.Contains('"')
                        || str.Contains('\r') || str.Contains('\n')) //含逗号 冒号 换行符的需要放到引号中
                    {
                        str = string.Format("\"{0}\"", str);
                    }

                    data += str;
                    if (j < dt.Columns.Count - 1)
                    {
                        data += ",";
                    }
                }
                sw.WriteLine(data);
            }
            sw.Close();
            fs.Close();
        }
        /// 设置LCDRAM显示的表格然后保存成csv格式
        /// <param name="data"></param>
        /// <returns></returns>
        public void SetLCDRAM(uint row,uint colums)
        {
            try
            {
                dataGridView.Visible = true;
                dt.Clear();

                dt.Rows.Clear();
                dt.Columns.Clear();
                dataGridView.DataSource = dt;
                String str1 = String.Empty;

                dt.Columns.Add("COM_SEG");
                for (int i = 0; i < (colums - 1); i++)
                {
                    str1 = "SEG" + i.ToString();
                    dt.Columns.Add(str1);
                }
                //按照COM设置行
                dt.Rows.Add("COM_SEG");
                //DataRow dr = dt.NewRow();
                for (int i = 0; i < row; i++)
                {
                    //dr[i] = "COM" + i.ToString();
                    //dt.Rows.Add(dr[i]);
                    str1 = "COM" + i.ToString();
                    dt.Rows.Add(str1);
                }

                dataGridView.ColumnHeadersVisible = false;
                //dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                dataGridView.GridColor = Color.Teal;
                dataGridView.BackgroundColor = Color.LightGreen;
                dataGridView.DataSource = dt;
                dataGridView.AllowUserToAddRows = false;
                dataGridView.EditMode = DataGridViewEditMode.EditOnEnter;
                dataGridView.RowHeadersVisible = false;

                //按照SEG设置列            
                //COM6 没有SEG38 SEG39//COM8 没有SEG36 SEG37
                for (int i = 1; i < (colums); i++)
                {
                    str1 = "SEG" + (i - 1).ToString();
                    this.dataGridView.Rows[0].Cells[i].Value = str1;
                    if (row >= 6)
                    {
                        if (str1 == "SEG38")
                        {
                            dataGridView.Columns[39].Visible = false;
                        }
                        if (str1 == "SEG39")
                        {
                            dataGridView.Columns[40].Visible = false;
                        }

                        if (row == 8)
                        {
                            if (str1 == "SEG36")
                            {
                                dataGridView.Columns[37].Visible = false;
                            }
                            if (str1 == "SEG37")
                            {
                                dataGridView.Columns[38].Visible = false;
                            }
                        }
                    }
                }
                //comboBox_LCD_SEG.Items.Clear();
                ////按照SEG设置列
                //int k = MAX_LCD_Seg + 1;
                if (row == 6)
                {
                    comboBox_LCD_SEG.Items.Remove("51SEG");
                    comboBox_LCD_SEG.Items.Remove("52SEG");
                    if (comboBox_LCD_SEG.Items.Count == 49)
                    {
                        comboBox_LCD_SEG.Items.Add("49SEG");
                        comboBox_LCD_SEG.Items.Add("50SEG");
                    }
                }
                else if (row == 8)
                {
                    comboBox_LCD_SEG.Items.Remove("49SEG");
                    comboBox_LCD_SEG.Items.Remove("50SEG");
                    comboBox_LCD_SEG.Items.Remove("51SEG");
                    comboBox_LCD_SEG.Items.Remove("52SEG");
                }
                else
                {
                    if (comboBox_LCD_SEG.Items.Count == 49)
                    {
                        comboBox_LCD_SEG.Items.Add("49SEG");
                        comboBox_LCD_SEG.Items.Add("50SEG");
                        comboBox_LCD_SEG.Items.Add("51SEG");
                        comboBox_LCD_SEG.Items.Add("52SEG");
                    }
                    if (comboBox_LCD_SEG.Items.Count == 51)
                    {
                        comboBox_LCD_SEG.Items.Add("51SEG");
                        comboBox_LCD_SEG.Items.Add("52SEG");
                    }
                }
                dataGridView.Rows[0].Cells[0].Value = "COM_SEG";
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                return;
            }
        }













        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDataSend = new SaveFileDialog();
            // Environment.SpecialFolder.MyDocuments 表示在我的文档中
            saveDataSend.InitialDirectory = System.Environment.CurrentDirectory;  // 获取文件路径
            //saveDataSend.Filter = "*.csv|csv file";   // 设置文件类型
            //saveDataSend.DefaultExt = ".csv";   // 默认文件的拓展名
            saveDataSend.FileName = "LCD_RAM.csv";   // 文件默认名
            if (saveDataSend.ShowDialog() == DialogResult.OK)   // 显示文件框，并且选择文件
            {
                SaveCSV(dt,saveDataSend.FileName);
             }
        }


        private void GetCOMSEGNum(int row, int colums)
        {
            int rowIndex = 0;

            switch (row - 1)
            {
                case 1: rowIndex = 0; break; //COM0
                case 2: rowIndex = 1; break; //COM2
                case 3: rowIndex = 2; break; //COM3
                case 4: rowIndex = 3; break;//COM4
                case 6: rowIndex = 4; break;//COM6
                case 8: rowIndex = 5; break;//COM8
                default: rowIndex = 3; break;
            }
            Current_COM = row - 1;
            Current_SEG = colums;
            comboBox_LCD_COM.SelectedIndex = rowIndex;
            comboBox_LCD_SEG.SelectedIndex = colums-  1;
            Delay(2);
            Disp_Flag = 0;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView.Visible = true;
            dt.Clear();
            dt.Rows.Clear();
            dt.Columns.Clear();
            OpenFileDialog openDataFile = new OpenFileDialog();
            //openDataFile.Filter = "*.csv|csv file";   // 设置文件类型
            //openDataFile.DefaultExt = ".csv";   // 默认文件的拓展名
            if (openDataFile.ShowDialog() == DialogResult.OK)
            {
                String str = openDataFile.FileName;
                dt = OpenCSV(str);
                int row = dt.Rows.Count;
                int columns = dt.Columns.Count;
                dataGridView.Visible = true;
                dataGridView.DataSource = dt;
                dataGridView.ColumnHeadersVisible = false;
                dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                //禁止以列排序;
                for (int i = 0; i < dataGridView.Columns.Count; i++)
                {
                    dataGridView.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                }

                dataGridView.AllowUserToAddRows = true;
                dataGridView.EditMode = DataGridViewEditMode.EditOnEnter;
                dataGridView.RowHeadersVisible = false;
                //修改COM和SEG值
                Disp_Flag = 1;         
                GetCOMSEGNum(row, columns);
            }          
        }




        private void ModefyLCDRAM()
        {
            int row = 4;
            
            switch (comboBox_LCD_COM.SelectedIndex)
            {
                case 0:  row = 1; break; //COM1
                case 1:  row = 2; break; //COM2
                case 2:  row = 3; break; //COM3
                case 3:  row = 4; break;//COM4
                case 4:  row = 6; break;//COM6
                case 5:  row = 8; break;//COM8
                default: row = 4; break;          
            }
            int colums = comboBox_LCD_SEG.SelectedIndex + 1;

            Current_COM = row;
            Current_SEG = colums;
            SetLCDRAM((uint)row, (uint)colums);

        }
        //LCD设置COM 改变LCD的RAM显示区域
        private void comboBox_LCD_COM_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Disp_Flag == 1) return;
            
            ModefyLCDRAM();
            BindCom();
            Select_Pic();
        }

        private void comboBox_LCD_SEG_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Disp_Flag == 1) return;
            ModefyLCDRAM();
        }



        String code_lcd = String.Empty;
        String code_start =
"/******************************************************************************\r\n" +
"* Copyright (C) 2018, Huada Semiconductor Co.,Ltd All rights reserved.\r\n" +
"*\r\n" +
"*/\r\n" +
"/******************************************************************************/\r\n" +
"/** file lcd_code.c\r\n" +
" **\r\n" +
" ** A detailed description is available at\r\n" +
" ** @link Sample Group Some description @endlink\r\n" +
" **\r\n" +
" **   - 2021-01-28  1.0  Devi First version for Device Driver Library of Module.\r\n" +
" **\r\n" +
" ******************************************************************************/\r\n" +
"\r\n" +
"/******************************************************************************\r\n" +
 "* Include files\r\n" +
 "******************************************************************************/\r\n" +
 "#include \"ddl.h\"\r\n" +
 "#include  <string.h>\r\n" +
 "\r\n" +
 "\r\n" +
"/******************************************************************************/\r\n" +
"#define		LCD_BASEADDR            M0P_LCD_BASE + 0x40 \r\n" +
"//COM6 :SEG38到SEG39没有使用\r\n" +
"//COM8 :SEG36到SEG39没有使用\r\n";


        String str_headstr =
        "/*******************************************************************************\r\n" +
        "功能描述：  显示全屏和清除显示\r\n" +
        "*******************************************************************************/\r\n" +
        "void Disp_Full_Clear(uint8_t temp)\r\n" +
        "{	\r\n";

public String LCD_Full_Clear()
{
    String str1 = str_headstr;
     for(int i = 0; i< MAX_LCD_Seg;i++)
     {
         String str2 = " LCDSEG" + i.ToString() + "  =  temp;\r\n";
         str1 = str1 + str2;
     }
     return str1 + "}\r\n";;
}

        String code_Digitline =
"//===============================================\r\n" +
"//数字显示函数\r\n" +
"//===============================================\r\n" ;

String code_OneDigitline = 
"\r\n" +
"void Disp_OneDigit(uint8_t  V_DataNum,uint8_t  V_Data)\r\n" + "{ ";
String code_OneDigitlineEnd =    
" \r\n} \r\n";

        //获取LCD和MCU显示对应寄存器
        public String LCD_COM_SEG_Map()
        {
            String str1 = "//LCD RAM regist \r\n";
            String str2 = "";
            for (int i = 0; i < 32; i++)
            { 
               str2 =  "#define LCDSEG" + i.ToString() +"  	*((volatile uint8_t *)(LCD_BASEADDR+" + i.ToString() + "))\r\n";
               str1 = str1 + str2;
            }
            for (int i = 32; i < 40; i++)
            {
                str2 = "#define LCDSEG" + i.ToString() + "  	*((volatile uint8_t *)(LCD_BASEADDR+" + (32 + (i - 32)*4).ToString() + "))\r\n";
                str1 = str1 + str2;
            }
            for (int i = 40; i < 48; i++)
            {
                str2 = "#define LCDSEG" + i.ToString() + "  	*((volatile uint8_t *)(LCD_BASEADDR+" + (33 + (i - 40) * 4).ToString() + "))\r\n";
                str1 = str1 + str2;
            }
            for (int i = 48; i < 52; i++)
            {
                str2 = "#define LCDSEG" + i.ToString() + "  	*((volatile uint8_t *)(LCD_BASEADDR+" + (34 + (i - 48) * 4).ToString() + "))\r\n";
                str1 = str1 + str2;
            }

            return str1;
        }



        String[] str_Digit = new String[10];
        //实现8字的描写转为0~9数字
        public void LCD_Str_Get()
        {
            str_Digit[0] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                           comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            str_Digit[1] = comboBox_Num_2.Text + comboBox_Num_3.Text;
            str_Digit[2] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                           comboBox_Num_4.Text + comboBox_Num_5.Text;
            str_Digit[3] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                           comboBox_Num_4.Text + comboBox_Num_3.Text;
            str_Digit[4] = comboBox_Num_6.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                           comboBox_Num_3.Text;
            str_Digit[5] = comboBox_Num_1.Text + comboBox_Num_6.Text + comboBox_Num_7.Text +
                           comboBox_Num_4.Text + comboBox_Num_3.Text;
            str_Digit[6] = comboBox_Num_1.Text + comboBox_Num_5.Text + comboBox_Num_7.Text +
                           comboBox_Num_4.Text + comboBox_Num_3.Text + comboBox_Num_6.Text;
            str_Digit[7] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text;
            str_Digit[8] = comboBox_Num_1.Text + comboBox_Num_5.Text + comboBox_Num_7.Text +
                           comboBox_Num_4.Text + comboBox_Num_3.Text + comboBox_Num_6.Text +
                           comboBox_Num_2.Text;
            str_Digit[9] = comboBox_Num_1.Text  + comboBox_Num_7.Text +
                           comboBox_Num_2.Text + comboBox_Num_3.Text + comboBox_Num_6.Text;
        }
        public String LCD_Num_Get(int num,int data)
        {
            String str2 = "";
            int len = str_Digit[data].Length;
            for (int i = 0; i < len; i++)
            { 
               String str1 = num.ToString() + str_Digit[data].Substring(i,1);
               for (int j = 0; j < Sys_Count; j++)
               {
                   if (str1 == Sys_Num[j])
                   {
                       str2 = str2 + " Fill_" + Sys_Num[j] + ";  ";
                   }
               }
            }
            return str2;
        }
        //实现每一个8字的描写
        public String LCD_Num_Digit(int num)
        {
           String str1 = "void LCD_Digit_" + num.ToString() + "(uint8_t V_Data)\r\n" +
          "{	\r\n" + "  if(V_Data>9)  return; \r\n";
            LCD_Str_Get();
            String str2 = "" + str1;
            String str3 = "  else if";
            for (int i = 0; i < 10; i++)
            {
                if (i == 0) str3 = "  if";
                else str3 = "  else if";
                str2 = str2 + str3 + "(V_Data == " + i.ToString() + " ) // 显示数字\r\n  {" + LCD_Num_Get(num, i) + "}\r\n";
            }
            return str2 + "}\r\n";
        }

        String[] str_MIDigit = new String[36];
        //实现MI字16
        public void LCD_StrMI_Get()
        {
            str_MIDigit[0] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_7.Text + comboBox_Num_8.Text;
            str_MIDigit[1] = comboBox_Num_3.Text + comboBox_Num_4.Text;
            str_MIDigit[2] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_13.Text + comboBox_Num_12.Text + comboBox_Num_7.Text +
                             comboBox_Num_6.Text + comboBox_Num_5.Text;
            str_MIDigit[3] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_13.Text + comboBox_Num_12.Text + comboBox_Num_4.Text +
                             comboBox_Num_6.Text + comboBox_Num_5.Text;
            str_MIDigit[4] = comboBox_Num_8.Text + comboBox_Num_3.Text +
                             comboBox_Num_13.Text + comboBox_Num_12.Text + comboBox_Num_4.Text;
            str_MIDigit[5] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_8.Text +
                             comboBox_Num_4.Text + comboBox_Num_13.Text + comboBox_Num_12.Text +
                             comboBox_Num_6.Text + comboBox_Num_5.Text;
            str_MIDigit[6] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                             comboBox_Num_8.Text + comboBox_Num_4.Text + comboBox_Num_6.Text +
                             comboBox_Num_5.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            str_MIDigit[7] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text + comboBox_Num_4.Text;
            str_MIDigit[8] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            str_MIDigit[9] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_8.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            //字母
            //A
            str_MIDigit[10] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_4.Text + comboBox_Num_7.Text + comboBox_Num_8.Text +
                              comboBox_Num_12.Text + comboBox_Num_13.Text;
            //B
            str_MIDigit[11] = comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            //C
            str_MIDigit[12] = comboBox_Num_1.Text + comboBox_Num_2.Text + 
                              comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //D
            str_MIDigit[13] = comboBox_Num_10.Text + comboBox_Num_15.Text + comboBox_Num_3.Text + comboBox_Num_1.Text + 
                              comboBox_Num_2.Text + comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //E
            str_MIDigit[14] = comboBox_Num_1.Text + comboBox_Num_2.Text + 
                              comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            //F
            str_MIDigit[15] = comboBox_Num_1.Text + comboBox_Num_2.Text +
                              comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            //G
            str_MIDigit[16] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                              comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_8.Text + comboBox_Num_13.Text;
            //H
            str_MIDigit[17] = comboBox_Num_3.Text + comboBox_Num_4.Text + comboBox_Num_7.Text + 
                              comboBox_Num_8.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;
            //I
            str_MIDigit[18] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_10.Text +
                              comboBox_Num_15.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //J
            str_MIDigit[19] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_10.Text +
                              comboBox_Num_15.Text + comboBox_Num_6.Text;
            //K
            str_MIDigit[20] = comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_12.Text +
                              comboBox_Num_11.Text + comboBox_Num_16.Text;
            //L
            str_MIDigit[21] = comboBox_Num_7.Text + comboBox_Num_8.Text + comboBox_Num_5.Text +
                              comboBox_Num_6.Text;
            //M
            str_MIDigit[22] = comboBox_Num_3.Text + comboBox_Num_4.Text + comboBox_Num_7.Text + 
                              comboBox_Num_8.Text + comboBox_Num_9.Text + comboBox_Num_11.Text;
            //N
            str_MIDigit[23] = comboBox_Num_3.Text + comboBox_Num_4.Text + comboBox_Num_7.Text +
                              comboBox_Num_8.Text + comboBox_Num_9.Text + comboBox_Num_16.Text;
            //O
            str_MIDigit[24] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_7.Text + comboBox_Num_8.Text;
            //P
            str_MIDigit[25] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_12.Text + comboBox_Num_13.Text +
                              comboBox_Num_7.Text + comboBox_Num_8.Text;
            //Q
            str_MIDigit[26] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_16.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_7.Text + comboBox_Num_4.Text + comboBox_Num_8.Text;
            //R
            str_MIDigit[27] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_12.Text + comboBox_Num_13.Text + comboBox_Num_16.Text +
                              comboBox_Num_7.Text + comboBox_Num_8.Text;
            //S
            str_MIDigit[28] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_8.Text +
                              comboBox_Num_12.Text + comboBox_Num_13.Text + comboBox_Num_4.Text +
                              comboBox_Num_5.Text + comboBox_Num_6.Text;
            //T
            str_MIDigit[29] = comboBox_Num_1.Text + comboBox_Num_2.Text + 
                              comboBox_Num_15.Text + comboBox_Num_10.Text;
            //U
            str_MIDigit[30] = comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_7.Text + comboBox_Num_8.Text;
            //V
            str_MIDigit[31] = comboBox_Num_7.Text +
                             comboBox_Num_8.Text + comboBox_Num_11.Text + comboBox_Num_14.Text;
            //W
            str_MIDigit[32] = comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_14.Text + comboBox_Num_16.Text +
                             comboBox_Num_7.Text + comboBox_Num_8.Text;
            //X
            str_MIDigit[33] = comboBox_Num_9.Text +
                             comboBox_Num_11.Text + comboBox_Num_14.Text + comboBox_Num_16.Text;
            //Y
            str_MIDigit[34] = comboBox_Num_4.Text + comboBox_Num_3.Text + comboBox_Num_6.Text + comboBox_Num_8.Text +
                              comboBox_Num_5.Text + comboBox_Num_12.Text + comboBox_Num_13.Text;

            //Z
            str_MIDigit[35] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_5.Text +
                              comboBox_Num_6.Text + comboBox_Num_11.Text + comboBox_Num_14.Text ;

        }

        //实现MI字14
        public void LCD_StrMI14_Get()
        {
            str_MIDigit[0] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;

            str_MIDigit[1] = comboBox_Num_2.Text + comboBox_Num_3.Text;
            str_MIDigit[2] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                             comboBox_Num_14.Text + comboBox_Num_5.Text + comboBox_Num_4.Text;

            str_MIDigit[3] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_7.Text + comboBox_Num_14.Text + comboBox_Num_4.Text;

            str_MIDigit[4] = comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_6.Text + comboBox_Num_14.Text + comboBox_Num_7.Text;
            str_MIDigit[5] = comboBox_Num_1.Text + comboBox_Num_6.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_14.Text + comboBox_Num_7.Text;
      
            str_MIDigit[6] = comboBox_Num_1.Text + comboBox_Num_3.Text + comboBox_Num_4.Text +
                             comboBox_Num_5.Text + comboBox_Num_6.Text + comboBox_Num_7.Text +
                             comboBox_Num_14.Text;
            str_MIDigit[7] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text;
            str_MIDigit[8] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_7.Text + comboBox_Num_14.Text ;
            str_MIDigit[9] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_7.Text + comboBox_Num_6.Text +
                             comboBox_Num_14.Text;
            //字母
            //A
            str_MIDigit[10] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_5.Text + comboBox_Num_6.Text + comboBox_Num_7.Text + comboBox_Num_14.Text;
            //B
            str_MIDigit[11] = comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_7.Text + comboBox_Num_14.Text + comboBox_Num_3.Text;
            //C
            str_MIDigit[12] = comboBox_Num_1.Text + comboBox_Num_4.Text +
                              comboBox_Num_5.Text + comboBox_Num_6.Text;
            //D
            str_MIDigit[13] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_4.Text + comboBox_Num_9.Text + comboBox_Num_12.Text;
            //E
            str_MIDigit[14] = comboBox_Num_1.Text + comboBox_Num_4.Text +
                              comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_7.Text + comboBox_Num_14.Text ;
            //F
            str_MIDigit[15] = comboBox_Num_1.Text + comboBox_Num_5.Text +
                              comboBox_Num_6.Text + comboBox_Num_7.Text + comboBox_Num_14.Text;
            //G
            str_MIDigit[16] = comboBox_Num_1.Text + comboBox_Num_7.Text + comboBox_Num_3.Text +
                              comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //H
            str_MIDigit[17] = comboBox_Num_3.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                              comboBox_Num_14.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //I
            str_MIDigit[18] = comboBox_Num_1.Text + comboBox_Num_9.Text + comboBox_Num_12.Text +
                              comboBox_Num_4.Text;
            //J
            str_MIDigit[19] = comboBox_Num_3.Text + comboBox_Num_4.Text + comboBox_Num_2.Text;
            //K
            str_MIDigit[20] = comboBox_Num_5.Text + comboBox_Num_6.Text + comboBox_Num_14.Text +
                              comboBox_Num_11.Text + comboBox_Num_10.Text;
            //L
            str_MIDigit[21] = comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //M
            str_MIDigit[22] = comboBox_Num_3.Text + comboBox_Num_2.Text + comboBox_Num_5.Text +
                              comboBox_Num_6.Text + comboBox_Num_8.Text + comboBox_Num_10.Text;
            //N
            str_MIDigit[23] = comboBox_Num_3.Text + comboBox_Num_2.Text + comboBox_Num_5.Text +
                              comboBox_Num_6.Text + comboBox_Num_8.Text + comboBox_Num_11.Text;
            //O
            str_MIDigit[24] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                             comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //P
            str_MIDigit[25] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_5.Text +
                              comboBox_Num_6.Text + comboBox_Num_14.Text +
                              comboBox_Num_7.Text;
            //Q
            str_MIDigit[26] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_3.Text +
                              comboBox_Num_4.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_11.Text;
            //R
            str_MIDigit[27] = comboBox_Num_1.Text + comboBox_Num_2.Text + comboBox_Num_7.Text +
                              comboBox_Num_14.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                              comboBox_Num_11.Text;
            //S
            str_MIDigit[28] = comboBox_Num_1.Text + comboBox_Num_4.Text + comboBox_Num_3.Text +
                              comboBox_Num_6.Text + comboBox_Num_14.Text + 
                              comboBox_Num_7.Text ;

            //T
            str_MIDigit[29] = comboBox_Num_1.Text + comboBox_Num_9.Text +  comboBox_Num_12.Text;
            //U
            str_MIDigit[30] = comboBox_Num_2.Text + comboBox_Num_3.Text + comboBox_Num_4.Text +
                              comboBox_Num_5.Text + comboBox_Num_6.Text;

            //V
            str_MIDigit[31] = comboBox_Num_13.Text +
                             comboBox_Num_10.Text + comboBox_Num_5.Text + comboBox_Num_6.Text;
            //W
            str_MIDigit[32] = comboBox_Num_3.Text + comboBox_Num_5.Text + comboBox_Num_6.Text +
                             comboBox_Num_2.Text + comboBox_Num_11.Text + comboBox_Num_13.Text;
            //X
            str_MIDigit[33] = comboBox_Num_8.Text +
                             comboBox_Num_10.Text + comboBox_Num_11.Text + comboBox_Num_13.Text;
   
            //Y
            str_MIDigit[34] = comboBox_Num_2.Text  + comboBox_Num_3.Text + comboBox_Num_4.Text +
                             comboBox_Num_6.Text + comboBox_Num_14.Text + comboBox_Num_7.Text;
            //Z
            str_MIDigit[35] = comboBox_Num_1.Text + comboBox_Num_4.Text + comboBox_Num_10.Text + comboBox_Num_13.Text;
   
        }







        public String LCD_NumMI_Get(int num, int data)
        {
            String str2 = "";
            int len = 0;

             len = str_MIDigit[data].Length;

            for (int i = 0; i < len; i++)
            {
                String str3 = "";
                if (num < 10)
                {
                    str3 = num.ToString();
                }
                else
                { 
                    char a = (char)('A' + (num - 10));
                    str3 = a.ToString();
                }
                String str1 = str3 + str_MIDigit[data].Substring(i, 1);
                for (int j = 0; j < Sys_Count; j++)
                {
                    if (str1 == Sys_Num[j])
                    {
                        str2 = str2 + " Fill_" + Sys_Num[j] + ";  ";
                    }
                }
            }
            return str2;
        }
        //实现每一个MI字的描写
        public String LCD_NumMI_Digit(int num)
        {
            String str1 = "void LCD_Digit_" + num.ToString() + "(uint8_t V_Data)\r\n" +
           "{	\r\n";
            if (radioButton_miDigit.Checked)
            {
                LCD_StrMI_Get();
            }
            else
            {
                LCD_StrMI14_Get();
            }
            String str2 = "" + str1;
            String str3 = "  else if";
            String str4 = "";
            for (int i = 0; i < 36; i++)
            {
                if (i == 0) str3 = "  if";
                else str3 = "  else if";
                
                if (i < 10)
                {
                     str4 = i.ToString();
                }
                else
                {
                    char a = (char)('A' + (i - 10));
                     str4 = a.ToString();
                }
                str2 = str2 + str3 + "(V_Data == " + i.ToString() + " )//   显示  " + str4 + "\r\n  {" + LCD_NumMI_Get(num, i) + "}\r\n";
            }
            return str2 + "}\r\n";
        }








        String str_LCD_Digits =
"///***********************************************************************************///\r\n" +
"///*Function：Disp_DigitS	                          		                         \r\n" +
"///*Description：底层数字转换           					 						 \r\n" +
"///***********************************************************************************///\r\n" +
"void Disp_DigitS(uint8_t  *P_Data,uint8_t   V_StartNum,uint8_t   V_Num)\r\n" +
"{\r\n" +
" uint8_t   V_CircleNum;\r\n" +
" for(V_CircleNum=V_StartNum; V_CircleNum<V_Num; V_CircleNum++)  \r\n" +
" { \r\n" +
"   Disp_OneDigit(V_CircleNum,P_Data[V_CircleNum] );	\r\n" +
" } \r\n" +
"}\r\n" +
"\r\n";

        //显示所有的8字函数
        public String LCD_Disp_OneDigit()
        {
            int k = Convert.ToInt16(textBox_Num.Text);
            String str1 = code_OneDigitline;
            for (int i = 1; i < (k+1); i++)
            {
                String str2 = "\r\n if( V_DataNum == " + i.ToString() + ")   LCD_Digit_" + i.ToString() + "( V_Data );";
                str1 = str1 + str2;
            }
            return str1 + code_OneDigitlineEnd;
        }
        //代码中显示每个点的宏定义
        public string LCD_RAM_Dot_Map()
        {
            String str = "#define    Fill_";
            String str1, str2, str3, str4;
            String num;
            int value = 0;
            str4 = "//点阵符号宏定义\r\n";
            int k = 0;
            for (int i = 0; i < Current_COM; i++)
            {
                str2 = dataGridView.Rows[i + 1].Cells[0].Value.ToString();
                if (str2 == "COM0")
                {
                    value = 0x01;
                }
                else if (str2 == "COM1")
                {
                    value = 0x02;
                }
                else if (str2 == "COM2")
                {
                    value = 0x04;
                }
                else if (str2 == "COM3")
                {
                    value = 0x08;
                }
                else if (str2 == "COM4")
                {
                    value = 10;
                }
                else if (str2 == "COM5")
                {
                    value = 20;
                }
                else if (str2 == "COM6")
                {
                    value = 40;
                }
                else if (str2 == "COM7")
                {
                    value = 80;
                }
                String str5 = "";

                for (int j = 1; j < Current_SEG; j++)
                {
                    str1 = dataGridView.Rows[i + 1].Cells[j].Value.ToString().Trim();
                    num = dataGridView.Rows[0].Cells[j].Value.ToString();
                    num = num.Substring(3, num.Length - 3);
                    if (str1 != "")
                    {
                        str5 = "      LCDSEG" + num + " |= 0x" + Convert.ToString(value);
                        str3 = str + str1 + str5 + "\r\n";
                        str4 = str4 + str3;
                        // 存为全局字符串
                        Sys_Num[k] = str1;
                        k++;
                    }
                }

            }
            Sys_Count = k;
            return str4;
        }


        //写TXT文件
        public bool WriteTXTFile(string str, string path)
        {
            try
            {
                StreamWriter streamWriter = new StreamWriter(path,false);
                streamWriter.Write(str);
                streamWriter.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);//显示异常信息
                return false;
            }
            return true;
        }

        //保存生成文件
        private void button_LCDcode_Click(object sender, EventArgs e)
        {
            if (textBox_Num.Text == "")
            {
                MessageBox.Show("输入显示数字个数！");
                return;
            }
            SaveFileDialog dlg = new SaveFileDialog();
            //dlg.Filter = "*.c|c source file";   // 设置文件类型
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                String str1 = "";
                string str = dlg.FileName;
                code_lcd = code_start + Define_HardMap() + LCD_COM_SEG_Map() + LCD_RAM_Dot_Map() + Config_LCD_IO() + LCD_Full_Clear();
                int k = Convert.ToInt16(textBox_Num.Text);
                for(int i = 0; i< k;i++)
                {
                    if (radioButton_8Digit.Checked == true)
                    {
                        str1 = str1 + LCD_Num_Digit(i + 1);
                    }
                    else
                    {
                        str1 = str1 + LCD_NumMI_Digit(i + 1);
                    }
                }

                code_lcd = code_lcd + code_Digitline + str1 + LCD_Disp_OneDigit() + str_LCD_Digits;
                str1 = str_LCD_Test.Replace("XXX", (k + 1).ToString());
                String str2 = Define_Dot();
                str1 = str1.Replace("Define_Dot", str2);

                if (radioButton_8Digit.Checked == true)
                {
                    str1 = str1.Replace("NN", "10");
                }
                else
                {
                    str1 = str1.Replace("NN", "36");
                }

                code_lcd = code_lcd + str1;

                if (WriteTXTFile(code_lcd, str) == true)
                {
                    //MessageBox.Show("保存TXT文件成功！");
                }
            }
        }
        //SEG 和 IO 对应数组
        String[] str_SEG_MAP = { "PA08", "PC09", "PC08", "PC07", "PC06", "PB15", "PB14", "PB13", "PB12", "PB11", "PB10" , //seg10
                                 "PB02", "PB01", "PB00", "PC05", "PC04", "PA07", "PA06", "PA05", "PA04", "PA03",  //seg20
                                 "PA02", "PA01", "PA00", "PC03", "PC02", "PC01", "PC00", "PB09", "PB08", "PF11",  //seg30
                                 "PB07", "PB06", "PB05", "PB04", "PB03", "PD02", "PC12", "PC11", "PC10", "PD15",  //seg40
                                 "PD14", "PD13", "PD12", "PD11", "PD10", "PD09", "PD08", "PE15", "PE14", "PE13",  //seg50
                                 "PE12",
                               };


        String str_ConfigLCD =
        "///*============================================*///\r\n" +
        "///* Function:   	void Initial_LCDDriver(void) \r\n" +
        "///* Description:	HDSC LCD 初始化代码	 		 \r\n" +
        "///*============================================*///\r\n" +
        "void Initial_LCDDriver(void)\r\n" +
        "{  \r\n" +
        "     M0P_SYSCTRL->PERI_CLKEN0_f.GPIO = 1;      //打开GPIO模块时钟\r\n" +
        "     M0P_SYSCTRL->RCL_CR_f.TRIM = *((volatile uint16_t*)(LCDCLK)); " +
        "     M0P_SYSCTRL->SYSCTRL2 = 0x5A5A;\r\n" +
        "     M0P_SYSCTRL->SYSCTRL2 = 0xA5A5;\r\n" +
        "     M0P_SYSCTRL->SYSCTRL0_f.RCL_EN = 1;     //内部低速RCL使能\r\n" +
        "     M0P_SYSCTRL->PERI_CLKEN0_f.LCD = 1;      //打开LCD模块时钟\r\n" +
        "     M0P_LCD->CR1  = 0;	\r\n";

        public String Config_LCD_IO()
        {
            String str_COM_IO = "//LCD IO中COM和SEG设置 \r\n" + "     M0P_GPIO->PAADS_f.PA09 = 1;//COM0 \r\n"
                 + "     M0P_LCD->POEN1_f.C0 = 0;//COM0 \r\n";
            if (Current_COM >= 2)
            {
                str_COM_IO = str_COM_IO + "     M0P_GPIO->PAADS_f.PA10 = 1;//COM1 \r\n"
                              + "     M0P_LCD->POEN1_f.C1 = 0;//COM1 \r\n";
            }
            if (Current_COM >= 3)
            {
                str_COM_IO = str_COM_IO + "     M0P_GPIO->PAADS_f.PA11 = 1;//COM2 \r\n"
                + "     M0P_LCD->POEN1_f.C2 = 0;//COM2 \r\n";
            }
            if (Current_COM >= 4)
            {
                str_COM_IO = str_COM_IO + "     M0P_GPIO->PAADS_f.PA12 = 1;//COM3 \r\n"
                + "     M0P_LCD->POEN1_f.C3 = 0;//COM3 \r\n";
            }
            if (Current_COM >= 6)
            {
                str_COM_IO = str_COM_IO + "     M0P_GPIO->PCADS_f.PC10 = 1;//COM4 \r\n" + "      M0P_GPIO->PCADS_f.PC11 = 1;//COM5 \r\n"
                              + "      M0P_LCD->POEN1_f.S39C4 = 0;//COM4 \r\n" + "      M0P_LCD->POEN1_f.S38C5 = 0;//COM5 \r\n";
            }
            if (Current_COM == 8)
            {
                str_COM_IO = str_COM_IO + "     M0P_GPIO->PCADS_f.PC12 = 1;//COM6 \r\n" + "     M0P_GPIO->PDADS_f.PD02 = 1;//COM7 \r\n"
                               + "     M0P_LCD->POEN1_f.S37C6 = 0;//COM6 \r\n" + "     M0P_LCD->POEN1_f.S36C7 = 0;//COM7 \r\n";
            }

            //LCD SEG 设置
            str_COM_IO = str_COM_IO + "//LCD IO中SEG设置 " + comboBox_LCD_SEG.Text + "\r\n";
            for (int i = 1; i < Current_SEG; i++)
            {
                string str0 = dataGridView.Rows[0].Cells[i].Value.ToString();
                string str1 = str0.Replace("SEG", "");
                int num = Convert.ToInt16(str1);
                String str2 = "";
                String str3 = "";
                String str4 = "";

                str2 = str_SEG_MAP[num]; //获得IO name
                str1 = str2.Substring(1, 1);
                str3 = "     M0P_GPIO->P" + str1 + "ADS_f." + str2 + " = 1; //" + str0 + "\r\n";
                if (num < 32)
                {
                    str4 = "     M0P_LCD->POEN0_f." + str0.Replace("SEG", "S") + " = 0; //" + str0 + "\r\n";
                }
                else
                {
                    if (num == 36)
                    {
                        str4 = "     M0P_LCD->POEN1_f.S36C7 = 1; // SEG36COM7  \r\n";
                    }
                    if (num == 37)
                    {
                        str4 = "     M0P_LCD->POEN1_f.S37C6 = 1; // SEG37COM6  \r\n";
                    }
                    if (num == 38)
                    {
                        str4 = "     M0P_LCD->POEN1_f.S38C5 = 1; // SEG38COM5  \r\n";
                    }
                    if (num == 39)
                    {
                        str4 = "     M0P_LCD->POEN1_f.S39C4 = 1; // SEG39COM4  \r\n";
                    }
                    else
                    {
                        str4 = "     M0P_LCD->POEN1_f." + str0.Replace("SEG", "S") + " = 1; //" + str0 + "\r\n";
                    }
                }
                str_COM_IO = str_COM_IO + str3 + str4;
            }

            if (LCD_Type != 0)  //LCD 类型不是内部驱动方式
            {
                String str1 = "//LCD 外部驱动IO设置 \r\n";
                str_COM_IO = str_COM_IO + str1 + "     M0P_GPIO->PBADS_f.PB03 = 1; //VLCDH \r\n" + "     M0P_GPIO->PBADS_f.PB04 = 1; //VLCD3 \r\n"
                                               + "     M0P_GPIO->PBADS_f.PB05 = 1; //VLCD2 \r\n" + "     M0P_GPIO->PBADS_f.PB06 = 1; //VLCD1 \r\n"
                                               + "     M0P_LCD->POEN1_f.S35 = 0; //VLCDH \r\n" + "     M0P_LCD->POEN1_f.S34 = 0; //VLCD3 \r\n"
                                               + "     M0P_LCD->POEN1_f.S33 = 0; //VLCD2 \r\n" + "     M0P_LCD->POEN1_f.S32 = 0; //VLCD1 \r\n";
            }

            str_COM_IO = str_COM_IO + "     M0P_LCD->POEN1_f.MUX = 0; //MUX \r\n";
            //RCL 时钟选择
            String str_clk = "";
            if (comboBox_LCDCLK.Text == "RCL_32.7KHz")
            {
                str_clk = "0x100c22));//" + label31.Text + comboBox_LCDCLK.Text + "\r\n";
            }
            else
            {
                str_clk = "0x100c20));//" + label31.Text + comboBox_LCDCLK.Text + "\r\n";
            }
            str_ConfigLCD = str_ConfigLCD.Replace("LCDCLK));", str_clk);
            return str_ConfigLCD + Config_LCD_CR() + str_COM_IO + "\r\n     M0P_LCD->CR0_f.EN = 1; //LCD 显示使能;\r\n}\r\n";
        }
        // MCU LCD IO & LCD IO
        public String Define_HardMap()
        {
            String str1 = "//HDSC MCU LCD模块中SEG和IO  与 段式LCD屏的引脚对应关系图 \r\n";
            String str2 = "//COM 对应关系\r\n";
            for (int i = 0; i < Current_COM; i++)
            {
                    str2 = str2 + "//" + dataGridView.Rows[i+1].Cells[0].Value + " ========== COM" + i.ToString() + "\r\n";
            }
            str2 = str2 + "//SEG 对应关系\r\n";
            for (int i = 0; i < Current_SEG - 1; i++)
            {
                str2 = str2 + "//" + dataGridView.Rows[0].Cells[i + 1].Value + " ========== SEG" + i.ToString() + "\r\n";
            }
            return str1 + str2;
        }


        public String Define_Dot()
        {
            String str1 = "//LCD 中宏定义显示 \r\n" + "    Disp_Full_Clear(0x00); //全清除\r\n";
            String str2 = "    delay1ms(500);\r\n";
            String str3 = "";
            for (int i = 0; i < Sys_Count; i++)
            {
                str3 = Sys_Num[i];

                if (Char.IsDigit(str3, 0) != true)
                {
                    str1 = str1 + str2 + "    Fill_" + Sys_Num[i] + ";\r\n";
                }
            }
            return str1;
        }



        String str_LCD_Test = 
"///***********************************************************************************///\r\n" +
"///*Function：Test_Display  LCD 显示测试程序\r\n" +	                          		                                					 						 
"///***********************************************************************************///\r\n" +
"void Test_Display(void)\r\n" +
"{\r\n" +
"   uint8_t i,j,buff[ XXX ];\r\n" +
"   Initial_LCDDriver();\r\n" +
"   memset(buff,0, XXX );\r\n" +
"   Disp_Full_Clear(0xFF); //全显示\r\n" +
"   for(i = 1; i < XXX; i++)//显示每一个数字\r\n" +
"   {\r\n" +
"     for(j = 0; j < NN; j++)\r\n" +
"     {\r\n" +
"      delay1ms(500);\r\n" +
"      Disp_Full_Clear(0x00); //全清除\r\n" +
"      Disp_OneDigit(i, j);	\r\n" +
"     }\r\n" +      
"   }\r\n "+
"   Disp_Full_Clear(0x00); //全清除\r\n" +
"   memset(buff,0, XXX );\r\n"+
"   for(i = 0; i < NN; i++)//显示所有的数字\r\n" +
"   {\r\n" +
"    for(j = 0; j < XXX;j++)\r\n" +
"    {\r\n" +
"     buff[j] = i;\r\n" +
"    }\r\n" +
"    Disp_DigitS(buff,1, XXX );	\r\n" +
"    delay1ms(500);\r\n" +
"    Disp_Full_Clear(0x00); //全清除\r\n" +
"   }\r\n Define_Dot" + 
"   while(1);\r\n" +
"}\r\n" ;
        //LCD CR寄存器设置
        public String Config_LCD_CR()
        {
            String str_cr = "//LCD CR寄存器设置 \r\n";
            String str1;
            int value;

            str_cr = str_cr + "     M0P_LCD->CR0_f.DUTY  =" + (Current_COM - 1).ToString() + ";//LCD Duty " + comboBox_LCD_COM.Text + "\r\n";

            value = comboBox_LCDType.SelectedIndex;
            if (value == 3)
            {
                value = 4;
            }
            else if (value == 4)
            {
                value = 6;
            }

            str1 = comboBox_LCDType.Text;
            str_cr = str_cr + "     M0P_LCD->CR0_f.BSEL  =" + value.ToString() + ";//" + str1 + " \r\n";

            value = comboBox_LCDConstrast.SelectedIndex;
            str_cr = str_cr + "     M0P_LCD->CR0_f.CONTRAST  =" + value.ToString() + ";//" + label13.Text + " \r\n";

            value = comboBox_LCDBias.SelectedIndex;
            str1 = comboBox_LCDBias.Text;
            str_cr = str_cr + "     M0P_LCD->CR0_f.BIAS  =" + value.ToString() + ";//" + label15.Text + str1 + " \r\n";

            value = comboBox_LCDCpClk.SelectedIndex;
            str1 = comboBox_LCDCpClk.Text;
            str_cr = str_cr + "     M0P_LCD->CR0_f.CPCLK  =" + value.ToString() + ";//" + label16.Text + str1 + " \r\n";

            value = comboBox_LCDLCK.SelectedIndex;
            str1 = comboBox_LCDLCK.Text;
            str_cr = str_cr + "     M0P_LCD->CR0_f.LCDCLK  =" + value.ToString() + ";//" + label17.Text + str1 + " \r\n";


            return str_cr;
        }

        //计算外部电阻时功耗模块
        private void Visable_Modle(bool temp)
        {
            button_LCDPower.Visible = temp;
            label14.Visible = temp;
            label18.Visible = temp;
            label19.Visible = temp;
            label20.Visible = temp;
            label21.Visible = temp;
            textBox1.Visible = temp; textBox2.Visible = temp; textBox3.Visible = temp; textBox4.Visible = temp; textBox5.Visible = temp;
            textBox1.Text = "3300"; textBox3.Text = "30000"; textBox4.Text = "100000";
        }

        //选择驱动图片
        void Select_Pic()
        {
            int value1 = comboBox_LCDType.SelectedIndex; //驱动方式
            int value2 = comboBox_LCDBias.SelectedIndex; //bias 偏置          
            int value3 = comboBox_LCD_COM.SelectedIndex; //COM 

            if((value3 == 0)&&(value1 == 1))   //静态外部电容方式
            {
                pictureBox1.Image = Properties.Resources.C_0;
            }
            else if ((value3 == 0) && (value1 == 0))   //静态外部电阻方式
            {
                pictureBox1.Image = Properties.Resources.R_0;
            }
            else if ((value2 == 0) && (value1 == 0))   //1/3bais 外部电阻方式
            {
                pictureBox1.Image = Properties.Resources.R_3;
            }
            else if ((value2 == 0) && (value1 == 1))   //1/3bais 外部电容方式
            {
                pictureBox1.Image = Properties.Resources.C_3;
            }
            else if ((value2 == 1) && (value1 == 0))   //1/2bais 外部电阻方式
            {
                pictureBox1.Image = Properties.Resources.R_2;
            }
            else if ((value2 == 1) && (value1 == 1))   //1/2bais 外部电容方式
            {
                pictureBox1.Image = Properties.Resources.C_2;
            }
            else
            {
                pictureBox1.Image = Properties.Resources.IN; //内部驱动方式
            }

        }



        //模式选择
        private void comboBox_LCDType_SelectedIndexChanged(object sender, EventArgs e)
        {                
            Visable_Modle(false);
            int value = comboBox_LCDType.SelectedIndex;
            if (value > 1)
            {
                LCD_Type = 0; //内部电阻方式
                richTextBox_LCDType.Text = str_inr;  
            }
            else
            {
                LCD_Type = 1;
                if (value == 0)
                {   
                    Visable_Modle(true);
                    richTextBox_LCDType.Text = str_exr;
                }
                else if (value == 1) richTextBox_LCDType.Text = str_exc;
            }
            Select_Pic();
        }
        //计算外部电阻模式下LCD功耗
        private void button_LCDPower_Click(object sender, EventArgs e)
        {
            float value1 = Convert.ToSingle(textBox1.Text);
            float value2 = Convert.ToSingle(textBox3.Text);
            float value3 = Convert.ToSingle(textBox4.Text);

            float value4 = (value1 / (value2 + 3 * value3)) * 3 * value3;
            float value5 = value1 / (value2 + 3 * value3) * 1000;
            textBox2.Text = value4.ToString();  //LCD电压
            textBox5.Text = value5.ToString();  //LCD 外部驱动电路电流
        }

        //MI字选择
        private void radioButton_miDigit_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_miDigit.Checked == true)
            {
                radioButton_8Digit.Checked = false;
                Config_8orMiDigit(true, 16);
            }
        }
        //米14字选择
        private void radioButton_mi14Digit_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_mi14Digit.Checked == true)
            {
                radioButton_8Digit.Checked = false;
                radioButton_miDigit.Checked = false;
                Config_8orMiDigit(true, 16);
            }
        }
        private void radioButton_8Digit_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_8Digit.Checked == true)
            {
                radioButton_miDigit.Checked = false;
                Config_8orMiDigit(false, 7);
            }
        }


        const int save_config_num = 19;
        void Get_Config_Name()
        {
            save_name[0] = radioButton_8Digit.Text;
            save_name[1] = radioButton_miDigit.Text;
            save_name[2] = label1.Text;
            save_name[3] = label2.Text;
            save_name[4] = label12.Text;
            save_name[5] = label13.Text;
            save_name[6] = label15.Text;
            save_name[7] = label16.Text;
            save_name[8] = label17.Text;
            save_name[9] = label14.Text;
            save_name[10] = label19.Text;
            save_name[11] = label20.Text;
            save_name[12] = "COM配置表";
            save_name[13] = "SEG配置表";
            save_name[14] = "点阵表";            
            save_name[15] = label11.Text;
            save_name[16] = "字配置表";
            save_name[17] = label31.Text;
            save_name[18] = radioButton_mi14Digit.Text;
        }
        void Save_Config_Value()
        {
            save_value[0] = (radioButton_8Digit.Checked).ToString();
            save_value[1] = (radioButton_miDigit.Checked).ToString();
            save_value[2] = (comboBox_LCD_COM.SelectedIndex).ToString();
            save_value[3] = (comboBox_LCD_SEG.SelectedIndex).ToString();
            save_value[4] = (comboBox_LCDType.SelectedIndex).ToString();
            save_value[5] = (comboBox_LCDConstrast.SelectedIndex).ToString();
            save_value[6] = (comboBox_LCDBias.SelectedIndex).ToString();
            save_value[7] = (comboBox_LCDCpClk.SelectedIndex).ToString();
            save_value[8] = (comboBox_LCDLCK.SelectedIndex).ToString();
            save_value[9] = (textBox1.Text).ToString();
            save_value[10] = (textBox3.Text).ToString();
            save_value[11] = (textBox4.Text).ToString();
            //COM
            String str1 = "";
            for (int i = 0; i < Current_COM; i++)
            {
                str1 = str1 + dataGridView.Rows[i + 1].Cells[0].Value.ToString() + ",";
            }
            save_value[12] = str1.Trim();
            //SEG
            str1 = "";
            for (int i = 0; i < Current_SEG - 1; i++)
            {
                str1 = str1 + dataGridView.Rows[0].Cells[i + 1].Value.ToString() + ",";
            }
            save_value[13] = str1.Trim();
            //data
            str1 = "";
            String str2 = "";
            for (int i = 0; i < Current_COM; i++)
            {
                for (int j = 0; j < Current_SEG - 1; j++)
                {
                    str2 = dataGridView.Rows[i + 1].Cells[j + 1].Value.ToString();
                    str1 = str1 + str2 + ",";
                }
                str1 = str1 + "\r\n";
            }
            save_value[14] = str1.Trim();
            //字个数
            save_value[15] = textBox_Num.Text;

            save_value[16] = comboBox_Num_1.SelectedIndex.ToString() + "," + comboBox_Num_2.SelectedIndex.ToString() + "," + comboBox_Num_3.SelectedIndex.ToString() + "," +
                             comboBox_Num_4.SelectedIndex.ToString() + "," + comboBox_Num_5.SelectedIndex.ToString() + "," + comboBox_Num_6.SelectedIndex.ToString() + "," +
                             comboBox_Num_7.SelectedIndex.ToString() + "," + comboBox_Num_8.SelectedIndex.ToString() + "," + comboBox_Num_9.SelectedIndex.ToString() + "," +
                             comboBox_Num_10.SelectedIndex.ToString() + "," + comboBox_Num_11.SelectedIndex.ToString() + "," + comboBox_Num_12.SelectedIndex.ToString() + "," +
                             comboBox_Num_13.SelectedIndex.ToString() + "," + comboBox_Num_14.SelectedIndex.ToString() + "," + comboBox_Num_15.SelectedIndex.ToString() + "," +
                             comboBox_Num_16.SelectedIndex.ToString() + ",";
            //LCD 时钟选择
            save_value[17] = comboBox_LCDCLK.SelectedIndex.ToString();
            save_value[18] = (radioButton_mi14Digit.Checked).ToString();
        }

        void Set_Config_Value()
        {
            (radioButton_8Digit.Checked) = Convert.ToBoolean(  save_value[0]);
            (radioButton_miDigit.Checked) = Convert.ToBoolean( save_value[1]);
            (radioButton_mi14Digit.Checked) = Convert.ToBoolean(save_value[18]);

            (comboBox_LCD_COM.SelectedIndex) = Convert.ToInt16( save_value[2]);
            (comboBox_LCD_SEG.SelectedIndex) = Convert.ToInt16(save_value[3]);
            (comboBox_LCDType.SelectedIndex) = Convert.ToInt16(save_value[4]);
            (comboBox_LCDConstrast.SelectedIndex) = Convert.ToInt16(save_value[5]);
            (comboBox_LCDBias.SelectedIndex) = Convert.ToInt16(save_value[6]);
            (comboBox_LCDCpClk.SelectedIndex) = Convert.ToInt16(save_value[7]);
            (comboBox_LCDLCK.SelectedIndex) = Convert.ToInt16(save_value[8]);
            (textBox1.Text) = save_value[9];
            (textBox3.Text) = save_value[10];
            (textBox4.Text) = save_value[11];
            dataGridView.Visible = true;
            dt.Clear();
            dt.Rows.Clear();
            dt.Columns.Clear();

            //SEG
            dt.Columns.Add("COM_SEG");
            String[] str2 = save_value[13].Split(',');
            for (int i = 1; i < str2.Length; i++)
            {
                dt.Columns.Add(str2[i]);
            }
            //COM
            dt.Rows.Add("COM_SEG");
            String[] str1 = save_value[12].Split(',');
            for (int i = 0; i < str1.Length; i++)
            {
                dt.Rows.Add(str1[i]);
            }

            //data
            String[] str3 = save_value[14].Split(',');
            int k = 0;
            for (int i = 0; i < str1.Length - 1; i++)
            {
                for (int j = 0; j < str2.Length - 1; j++)
                {
                    dt.Rows[i+1][j+1] = str3[k];
                    k++;
                }
            }

            for (int i = 1; i < str2.Length; i++)
            {
                dt.Rows[0][i]  = (str2[i-1]);
            }
            //字个数
           textBox_Num.Text = save_value[15];

            //字的配置
           str1 = save_value[16].Split(',');
           if (save_value[16] != "")
           {
               comboBox_Num_1.SelectedIndex = Convert.ToInt16(str1[0]);
               comboBox_Num_2.SelectedIndex = Convert.ToInt16(str1[1]);
               comboBox_Num_3.SelectedIndex = Convert.ToInt16(str1[2]);
               comboBox_Num_4.SelectedIndex = Convert.ToInt16(str1[3]);
               comboBox_Num_5.SelectedIndex = Convert.ToInt16(str1[4]);
               comboBox_Num_6.SelectedIndex = Convert.ToInt16(str1[5]);
               comboBox_Num_7.SelectedIndex = Convert.ToInt16(str1[6]);
               comboBox_Num_8.SelectedIndex = Convert.ToInt16(str1[7]);
               comboBox_Num_9.SelectedIndex = Convert.ToInt16(str1[8]);
               comboBox_Num_10.SelectedIndex = Convert.ToInt16(str1[9]);
               comboBox_Num_11.SelectedIndex = Convert.ToInt16(str1[10]);
               comboBox_Num_12.SelectedIndex = Convert.ToInt16(str1[11]);
               comboBox_Num_13.SelectedIndex = Convert.ToInt16(str1[12]);
               comboBox_Num_14.SelectedIndex = Convert.ToInt16(str1[13]);
               comboBox_Num_15.SelectedIndex = Convert.ToInt16(str1[14]);
               comboBox_Num_16.SelectedIndex = Convert.ToInt16(str1[15]);
           }

           //LCD 时钟选择
           (comboBox_LCDCLK.SelectedIndex) = Convert.ToInt16(save_value[17]);
           dataGridView.DataSource = dt;
        }

        //保存XML配置文件
        private void button_SaveXML_Click(object sender, EventArgs e)
        {
            try
            {
                Save_Config_Value();
                SaveFileDialog saveDataSend = new SaveFileDialog();
                saveDataSend.InitialDirectory = System.Environment.CurrentDirectory;  // 获取文件路径
                //saveDataSend.Filter = "*.*|xml file";   // 设置文件类型
                //删除文件

                if (saveDataSend.ShowDialog() == DialogResult.OK)   // 显示文件框，并且选择文件
                {
                    int flag = 0;

                    String[] str1 = new String[2];
                    str1[0] = ""; str1[1] = "";
                    if (System.IO.File.Exists(saveDataSend.FileName))
                    {
                        System.IO.File.Delete(saveDataSend.FileName);
                        FileStream TextFile = System.IO.File.Create(saveDataSend.FileName);
                        TextFile.Close();
                    }

                    XmlDocument xml_creat = new XmlDocument();

                    String str2 = xml_operate.CreateXmlFile(xml_creat, saveDataSend.FileName, save_name, save_value, save_config_num, flag);
                    if (str2 != null)
                    {
                        MessageBox.Show(str2.ToString());
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
                return;
            }
        }
        //读出XML配置文件
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDataFile = new OpenFileDialog();
            //openDataFile.Filter = "*.*|xml file";   // 设置文件类型
            if (openDataFile.ShowDialog() == DialogResult.OK)
            {
                String str = openDataFile.FileName;
                for (int i = 0; i < save_config_num; i++)
                {
                   save_value[i] =  xml_operate.ReadXmlFileNode(xmlDoc, str, save_name[i]);
                }
            }
            Set_Config_Value();
            Select_Pic();
        }

        private void comboBox_LCDBias_SelectedIndexChanged(object sender, EventArgs e)
        {
            Select_Pic();
        }




    }
}
