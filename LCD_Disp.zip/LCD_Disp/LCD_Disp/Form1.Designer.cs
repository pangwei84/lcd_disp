﻿namespace LCD_Disp
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox_LCD_COM = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_LCD_SEG = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_LCDcode = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox_Num_16 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBox_Num_15 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox_Num_14 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox_Num_13 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.comboBox_Num_12 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.comboBox_Num_11 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox_Num_10 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox_Num_9 = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBox_Num_8 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_Num = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox_Num_7 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox_Num_6 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_Num_5 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_Num_4 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_Num_3 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_Num_2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox_Num_1 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox_LCDCLK = new System.Windows.Forms.ComboBox();
            this.radioButton_miDigit = new System.Windows.Forms.RadioButton();
            this.radioButton_8Digit = new System.Windows.Forms.RadioButton();
            this.button_LCDPower = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.richTextBox_LCDType = new System.Windows.Forms.RichTextBox();
            this.comboBox_LCDLCK = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox_LCDCpClk = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox_LCDBias = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox_LCDConstrast = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox_LCDType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button_SaveXML = new System.Windows.Forms.Button();
            this.radioButton_mi14Digit = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(909, 227);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "保存真值表";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToOrderColumns = true;
            this.dataGridView.ColumnHeadersHeight = 16;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView.Location = new System.Drawing.Point(14, 289);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 20;
            this.dataGridView.RowTemplate.Height = 23;
            this.dataGridView.Size = new System.Drawing.Size(968, 229);
            this.dataGridView.TabIndex = 1;
            this.dataGridView.CurrentCellChanged += new System.EventHandler(this.dataGridView_CurrentCellChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(909, 29);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 36);
            this.button2.TabIndex = 2;
            this.button2.Text = "打开真值表";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(910, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(73, 36);
            this.button3.TabIndex = 3;
            this.button3.Text = "读出XML";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // comboBox_LCD_COM
            // 
            this.comboBox_LCD_COM.FormattingEnabled = true;
            this.comboBox_LCD_COM.Location = new System.Drawing.Point(142, 54);
            this.comboBox_LCD_COM.Name = "comboBox_LCD_COM";
            this.comboBox_LCD_COM.Size = new System.Drawing.Size(66, 20);
            this.comboBox_LCD_COM.TabIndex = 4;
            this.comboBox_LCD_COM.SelectedIndexChanged += new System.EventHandler(this.comboBox_LCD_COM_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "LCD模块COM选择";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "LCD模块SEG设置";
            // 
            // comboBox_LCD_SEG
            // 
            this.comboBox_LCD_SEG.DropDownWidth = 40;
            this.comboBox_LCD_SEG.FormattingEnabled = true;
            this.comboBox_LCD_SEG.Location = new System.Drawing.Point(141, 79);
            this.comboBox_LCD_SEG.Name = "comboBox_LCD_SEG";
            this.comboBox_LCD_SEG.Size = new System.Drawing.Size(67, 20);
            this.comboBox_LCD_SEG.TabIndex = 6;
            this.comboBox_LCD_SEG.SelectedIndexChanged += new System.EventHandler(this.comboBox_LCD_SEG_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "LCD模块RAM区域显示";
            // 
            // button_LCDcode
            // 
            this.button_LCDcode.Location = new System.Drawing.Point(910, 183);
            this.button_LCDcode.Name = "button_LCDcode";
            this.button_LCDcode.Size = new System.Drawing.Size(73, 36);
            this.button_LCDcode.TabIndex = 11;
            this.button_LCDcode.Text = "生成代码";
            this.button_LCDcode.UseVisualStyleBackColor = true;
            this.button_LCDcode.Click += new System.EventHandler(this.button_LCDcode_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.comboBox_Num_16);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.comboBox_Num_15);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.comboBox_Num_14);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.comboBox_Num_13);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.comboBox_Num_12);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.comboBox_Num_11);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.comboBox_Num_10);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.comboBox_Num_9);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.comboBox_Num_8);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textBox_Num);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.comboBox_Num_7);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.comboBox_Num_6);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.comboBox_Num_5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.comboBox_Num_4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboBox_Num_3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.comboBox_Num_2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBox_Num_1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Location = new System.Drawing.Point(621, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(282, 254);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "8字配置";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(202, 234);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 49;
            this.label22.Text = "16";
            // 
            // comboBox_Num_16
            // 
            this.comboBox_Num_16.FormattingEnabled = true;
            this.comboBox_Num_16.Location = new System.Drawing.Point(222, 231);
            this.comboBox_Num_16.Name = "comboBox_Num_16";
            this.comboBox_Num_16.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_16.TabIndex = 48;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(205, 210);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 12);
            this.label30.TabIndex = 47;
            this.label30.Text = "15";
            // 
            // comboBox_Num_15
            // 
            this.comboBox_Num_15.FormattingEnabled = true;
            this.comboBox_Num_15.Location = new System.Drawing.Point(222, 205);
            this.comboBox_Num_15.Name = "comboBox_Num_15";
            this.comboBox_Num_15.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_15.TabIndex = 46;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(205, 184);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 12);
            this.label23.TabIndex = 45;
            this.label23.Text = "14";
            // 
            // comboBox_Num_14
            // 
            this.comboBox_Num_14.FormattingEnabled = true;
            this.comboBox_Num_14.Location = new System.Drawing.Point(222, 179);
            this.comboBox_Num_14.Name = "comboBox_Num_14";
            this.comboBox_Num_14.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_14.TabIndex = 44;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(205, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 12);
            this.label24.TabIndex = 43;
            this.label24.Text = "13";
            // 
            // comboBox_Num_13
            // 
            this.comboBox_Num_13.FormattingEnabled = true;
            this.comboBox_Num_13.Location = new System.Drawing.Point(222, 153);
            this.comboBox_Num_13.Name = "comboBox_Num_13";
            this.comboBox_Num_13.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_13.TabIndex = 42;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(205, 130);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 12);
            this.label25.TabIndex = 41;
            this.label25.Text = "12";
            // 
            // comboBox_Num_12
            // 
            this.comboBox_Num_12.FormattingEnabled = true;
            this.comboBox_Num_12.Location = new System.Drawing.Point(222, 125);
            this.comboBox_Num_12.Name = "comboBox_Num_12";
            this.comboBox_Num_12.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_12.TabIndex = 40;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(205, 104);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 12);
            this.label26.TabIndex = 39;
            this.label26.Text = "11";
            // 
            // comboBox_Num_11
            // 
            this.comboBox_Num_11.FormattingEnabled = true;
            this.comboBox_Num_11.Location = new System.Drawing.Point(222, 99);
            this.comboBox_Num_11.Name = "comboBox_Num_11";
            this.comboBox_Num_11.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_11.TabIndex = 38;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(205, 78);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 12);
            this.label27.TabIndex = 37;
            this.label27.Text = "10";
            // 
            // comboBox_Num_10
            // 
            this.comboBox_Num_10.FormattingEnabled = true;
            this.comboBox_Num_10.Location = new System.Drawing.Point(222, 73);
            this.comboBox_Num_10.Name = "comboBox_Num_10";
            this.comboBox_Num_10.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_10.TabIndex = 36;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(205, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(11, 12);
            this.label28.TabIndex = 35;
            this.label28.Text = "9";
            // 
            // comboBox_Num_9
            // 
            this.comboBox_Num_9.FormattingEnabled = true;
            this.comboBox_Num_9.Location = new System.Drawing.Point(222, 47);
            this.comboBox_Num_9.Name = "comboBox_Num_9";
            this.comboBox_Num_9.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_9.TabIndex = 34;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(205, 26);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(11, 12);
            this.label29.TabIndex = 32;
            this.label29.Text = "8";
            // 
            // comboBox_Num_8
            // 
            this.comboBox_Num_8.FormattingEnabled = true;
            this.comboBox_Num_8.Location = new System.Drawing.Point(222, 21);
            this.comboBox_Num_8.Name = "comboBox_Num_8";
            this.comboBox_Num_8.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_8.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(148, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 30;
            this.label11.Text = "数字个数";
            // 
            // textBox_Num
            // 
            this.textBox_Num.Location = new System.Drawing.Point(156, 224);
            this.textBox_Num.Name = "textBox_Num";
            this.textBox_Num.Size = new System.Drawing.Size(38, 21);
            this.textBox_Num.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(139, 183);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 12);
            this.label10.TabIndex = 29;
            this.label10.Text = "7";
            // 
            // comboBox_Num_7
            // 
            this.comboBox_Num_7.FormattingEnabled = true;
            this.comboBox_Num_7.Location = new System.Drawing.Point(156, 178);
            this.comboBox_Num_7.Name = "comboBox_Num_7";
            this.comboBox_Num_7.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_7.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(139, 157);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(11, 12);
            this.label9.TabIndex = 27;
            this.label9.Text = "6";
            // 
            // comboBox_Num_6
            // 
            this.comboBox_Num_6.FormattingEnabled = true;
            this.comboBox_Num_6.Location = new System.Drawing.Point(156, 152);
            this.comboBox_Num_6.Name = "comboBox_Num_6";
            this.comboBox_Num_6.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_6.TabIndex = 26;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(139, 129);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 25;
            this.label8.Text = "5";
            // 
            // comboBox_Num_5
            // 
            this.comboBox_Num_5.FormattingEnabled = true;
            this.comboBox_Num_5.Location = new System.Drawing.Point(156, 124);
            this.comboBox_Num_5.Name = "comboBox_Num_5";
            this.comboBox_Num_5.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_5.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(139, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(11, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "4";
            // 
            // comboBox_Num_4
            // 
            this.comboBox_Num_4.FormattingEnabled = true;
            this.comboBox_Num_4.Location = new System.Drawing.Point(156, 98);
            this.comboBox_Num_4.Name = "comboBox_Num_4";
            this.comboBox_Num_4.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_4.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(139, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 12);
            this.label6.TabIndex = 21;
            this.label6.Text = "3";
            // 
            // comboBox_Num_3
            // 
            this.comboBox_Num_3.FormattingEnabled = true;
            this.comboBox_Num_3.Location = new System.Drawing.Point(156, 72);
            this.comboBox_Num_3.Name = "comboBox_Num_3";
            this.comboBox_Num_3.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_3.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(139, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(11, 12);
            this.label5.TabIndex = 19;
            this.label5.Text = "2";
            // 
            // comboBox_Num_2
            // 
            this.comboBox_Num_2.FormattingEnabled = true;
            this.comboBox_Num_2.Location = new System.Drawing.Point(156, 46);
            this.comboBox_Num_2.Name = "comboBox_Num_2";
            this.comboBox_Num_2.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_2.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(139, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 12);
            this.label4.TabIndex = 17;
            this.label4.Text = "1";
            // 
            // comboBox_Num_1
            // 
            this.comboBox_Num_1.FormattingEnabled = true;
            this.comboBox_Num_1.Location = new System.Drawing.Point(156, 20);
            this.comboBox_Num_1.Name = "comboBox_Num_1";
            this.comboBox_Num_1.Size = new System.Drawing.Size(47, 20);
            this.comboBox_Num_1.TabIndex = 16;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton_mi14Digit);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.comboBox_LCDCLK);
            this.groupBox2.Controls.Add(this.radioButton_miDigit);
            this.groupBox2.Controls.Add(this.radioButton_8Digit);
            this.groupBox2.Controls.Add(this.button_LCDPower);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.comboBox_LCDLCK);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.comboBox_LCDCpClk);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.comboBox_LCDBias);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.comboBox_LCDConstrast);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.comboBox_LCDType);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.comboBox_LCD_COM);
            this.groupBox2.Controls.Add(this.comboBox_LCD_SEG);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(603, 254);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "HDSC LCD模块配置";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 34);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(95, 12);
            this.label31.TabIndex = 23;
            this.label31.Text = "LCD模块时钟选择";
            // 
            // comboBox_LCDCLK
            // 
            this.comboBox_LCDCLK.FormattingEnabled = true;
            this.comboBox_LCDCLK.Location = new System.Drawing.Point(107, 31);
            this.comboBox_LCDCLK.Name = "comboBox_LCDCLK";
            this.comboBox_LCDCLK.Size = new System.Drawing.Size(101, 20);
            this.comboBox_LCDCLK.TabIndex = 22;
            // 
            // radioButton_miDigit
            // 
            this.radioButton_miDigit.AutoSize = true;
            this.radioButton_miDigit.Location = new System.Drawing.Point(92, 15);
            this.radioButton_miDigit.Name = "radioButton_miDigit";
            this.radioButton_miDigit.Size = new System.Drawing.Size(59, 16);
            this.radioButton_miDigit.TabIndex = 21;
            this.radioButton_miDigit.TabStop = true;
            this.radioButton_miDigit.Text = "米16字";
            this.radioButton_miDigit.UseVisualStyleBackColor = true;
            this.radioButton_miDigit.CheckedChanged += new System.EventHandler(this.radioButton_miDigit_CheckedChanged);
            // 
            // radioButton_8Digit
            // 
            this.radioButton_8Digit.AutoSize = true;
            this.radioButton_8Digit.Location = new System.Drawing.Point(8, 15);
            this.radioButton_8Digit.Name = "radioButton_8Digit";
            this.radioButton_8Digit.Size = new System.Drawing.Size(65, 16);
            this.radioButton_8Digit.TabIndex = 20;
            this.radioButton_8Digit.TabStop = true;
            this.radioButton_8Digit.Text = "字8配置";
            this.radioButton_8Digit.UseVisualStyleBackColor = true;
            this.radioButton_8Digit.CheckedChanged += new System.EventHandler(this.radioButton_8Digit_CheckedChanged);
            // 
            // button_LCDPower
            // 
            this.button_LCDPower.Location = new System.Drawing.Point(8, 224);
            this.button_LCDPower.Name = "button_LCDPower";
            this.button_LCDPower.Size = new System.Drawing.Size(87, 26);
            this.button_LCDPower.TabIndex = 18;
            this.button_LCDPower.Text = "计算LCD功耗";
            this.button_LCDPower.UseVisualStyleBackColor = true;
            this.button_LCDPower.Click += new System.EventHandler(this.button_LCDPower_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.richTextBox_LCDType);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Location = new System.Drawing.Point(214, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(383, 233);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "LCD模块驱动电路";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(154, 205);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(77, 21);
            this.textBox5.TabIndex = 15;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(154, 105);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(77, 21);
            this.textBox4.TabIndex = 14;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(154, 68);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(77, 21);
            this.textBox3.TabIndex = 13;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(154, 164);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(77, 21);
            this.textBox2.TabIndex = 12;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(153, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(77, 21);
            this.textBox1.TabIndex = 11;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(143, 189);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(101, 12);
            this.label21.TabIndex = 10;
            this.label21.Text = "驱动电路电流(uA)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(154, 91);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 12);
            this.label20.TabIndex = 9;
            this.label20.Text = "R电阻Ω";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(154, 53);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 8;
            this.label19.Text = "RX电阻Ω";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(154, 149);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 12);
            this.label18.TabIndex = 7;
            this.label18.Text = "LCD屏电压(mV)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(154, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 6;
            this.label14.Text = "VDD电压mV";
            // 
            // richTextBox_LCDType
            // 
            this.richTextBox_LCDType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox_LCDType.Location = new System.Drawing.Point(243, 14);
            this.richTextBox_LCDType.Name = "richTextBox_LCDType";
            this.richTextBox_LCDType.ReadOnly = true;
            this.richTextBox_LCDType.Size = new System.Drawing.Size(140, 213);
            this.richTextBox_LCDType.TabIndex = 1;
            this.richTextBox_LCDType.Text = "";
            // 
            // comboBox_LCDLCK
            // 
            this.comboBox_LCDLCK.DropDownWidth = 40;
            this.comboBox_LCDLCK.FormattingEnabled = true;
            this.comboBox_LCDLCK.Items.AddRange(new object[] {
            "00:64Hz",
            "01:128Hz",
            "10:256Hz",
            "11:512Hz"});
            this.comboBox_LCDLCK.Location = new System.Drawing.Point(141, 211);
            this.comboBox_LCDLCK.Name = "comboBox_LCDLCK";
            this.comboBox_LCDLCK.Size = new System.Drawing.Size(67, 20);
            this.comboBox_LCDLCK.TabIndex = 17;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(40, 213);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 12);
            this.label17.TabIndex = 18;
            this.label17.Text = "LCD扫描频率设置";
            // 
            // comboBox_LCDCpClk
            // 
            this.comboBox_LCDCpClk.DropDownWidth = 40;
            this.comboBox_LCDCpClk.FormattingEnabled = true;
            this.comboBox_LCDCpClk.Items.AddRange(new object[] {
            "00:2kHz",
            "01:4kHz",
            "10:8kHz",
            "11:16kHz"});
            this.comboBox_LCDCpClk.Location = new System.Drawing.Point(142, 183);
            this.comboBox_LCDCpClk.Name = "comboBox_LCDCpClk";
            this.comboBox_LCDCpClk.Size = new System.Drawing.Size(66, 20);
            this.comboBox_LCDCpClk.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 186);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(131, 12);
            this.label16.TabIndex = 16;
            this.label16.Text = "LCD电荷泵时钟频率设置";
            // 
            // comboBox_LCDBias
            // 
            this.comboBox_LCDBias.DropDownWidth = 40;
            this.comboBox_LCDBias.FormattingEnabled = true;
            this.comboBox_LCDBias.Items.AddRange(new object[] {
            "0:1/3 bias",
            "1:1/2 bias"});
            this.comboBox_LCDBias.Location = new System.Drawing.Point(141, 157);
            this.comboBox_LCDBias.Name = "comboBox_LCDBias";
            this.comboBox_LCDBias.Size = new System.Drawing.Size(67, 20);
            this.comboBox_LCDBias.TabIndex = 13;
            this.comboBox_LCDBias.SelectedIndexChanged += new System.EventHandler(this.comboBox_LCDBias_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 160);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 12);
            this.label15.TabIndex = 14;
            this.label15.Text = "LCD偏置bias设置";
            // 
            // comboBox_LCDConstrast
            // 
            this.comboBox_LCDConstrast.DropDownWidth = 40;
            this.comboBox_LCDConstrast.FormattingEnabled = true;
            this.comboBox_LCDConstrast.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBox_LCDConstrast.Location = new System.Drawing.Point(141, 131);
            this.comboBox_LCDConstrast.Name = "comboBox_LCDConstrast";
            this.comboBox_LCDConstrast.Size = new System.Drawing.Size(67, 20);
            this.comboBox_LCDConstrast.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 134);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(137, 12);
            this.label13.TabIndex = 11;
            this.label13.Text = "内部电阻驱动对比度调节";
            // 
            // comboBox_LCDType
            // 
            this.comboBox_LCDType.DropDownWidth = 40;
            this.comboBox_LCDType.FormattingEnabled = true;
            this.comboBox_LCDType.Items.AddRange(new object[] {
            "外部电阻",
            "外部电容",
            "内部电阻(中功耗模式)",
            "内部电阻(小功耗模式)",
            "内部电阻(大功耗模式)"});
            this.comboBox_LCDType.Location = new System.Drawing.Point(107, 105);
            this.comboBox_LCDType.Name = "comboBox_LCDType";
            this.comboBox_LCDType.Size = new System.Drawing.Size(101, 20);
            this.comboBox_LCDType.TabIndex = 8;
            this.comboBox_LCDType.SelectedIndexChanged += new System.EventHandler(this.comboBox_LCDType_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 12);
            this.label12.TabIndex = 9;
            this.label12.Text = "LCD驱动方式选择";
            // 
            // button_SaveXML
            // 
            this.button_SaveXML.Location = new System.Drawing.Point(910, 132);
            this.button_SaveXML.Name = "button_SaveXML";
            this.button_SaveXML.Size = new System.Drawing.Size(73, 36);
            this.button_SaveXML.TabIndex = 18;
            this.button_SaveXML.Text = "保存XML";
            this.button_SaveXML.UseVisualStyleBackColor = true;
            this.button_SaveXML.Click += new System.EventHandler(this.button_SaveXML_Click);
            // 
            // radioButton_mi14Digit
            // 
            this.radioButton_mi14Digit.AutoSize = true;
            this.radioButton_mi14Digit.Location = new System.Drawing.Point(157, 15);
            this.radioButton_mi14Digit.Name = "radioButton_mi14Digit";
            this.radioButton_mi14Digit.Size = new System.Drawing.Size(59, 16);
            this.radioButton_mi14Digit.TabIndex = 24;
            this.radioButton_mi14Digit.TabStop = true;
            this.radioButton_mi14Digit.Text = "米14字";
            this.radioButton_mi14Digit.UseVisualStyleBackColor = true;
            this.radioButton_mi14Digit.CheckedChanged += new System.EventHandler(this.radioButton_mi14Digit_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LCD_Disp.Properties.Resources.R_3;
            this.pictureBox1.Location = new System.Drawing.Point(6, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 214);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LCD_Disp.Properties.Resources.MI_14;
            this.pictureBox2.Location = new System.Drawing.Point(6, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(131, 219);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 530);
            this.Controls.Add(this.button_SaveXML);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_LCDcode);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "HDSC LCD模块辅助软件V1.0(HC32L/F13/7/9/6、HC32F/L073)";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox_LCD_COM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_LCD_SEG;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_LCDcode;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox_Num_7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox_Num_6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_Num_5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox_Num_4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox_Num_3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_Num_2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox_Num_1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_Num;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox_LCDLCK;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox_LCDCpClk;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox_LCDBias;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox_LCDConstrast;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox_LCDType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RichTextBox richTextBox_LCDType;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button_LCDPower;
        private System.Windows.Forms.RadioButton radioButton_miDigit;
        private System.Windows.Forms.RadioButton radioButton_8Digit;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox_Num_16;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBox_Num_15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox_Num_14;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox_Num_13;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox comboBox_Num_12;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comboBox_Num_11;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox_Num_10;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox_Num_9;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox_Num_8;
        private System.Windows.Forms.Button button_SaveXML;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox_LCDCLK;
        private System.Windows.Forms.RadioButton radioButton_mi14Digit;
    }
}

